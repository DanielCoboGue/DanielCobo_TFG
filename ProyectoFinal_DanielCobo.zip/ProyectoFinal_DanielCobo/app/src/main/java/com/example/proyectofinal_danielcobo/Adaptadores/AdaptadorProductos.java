package com.example.proyectofinal_danielcobo.Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo2.R;

import java.util.List;

public class AdaptadorProductos extends BaseAdapter {
    //Creamos variables que vamos a necesitar
    Context contexto;
    List<Productos> productos;
    LayoutInflater inflater;
    public AdaptadorProductos(Context contexto, List<Productos> productos) {
        this.contexto = contexto;
        this.productos = productos;
        inflater = LayoutInflater.from(contexto);

    }

    @Override
    public int getCount() {
        return productos.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Le pasamos a la lista como tiene que ser cada posicion de ella mediante el estilo
        view = inflater.inflate(R.layout.activity_estilo_productos, null);

        //Tomamos el producto que se encuentra en la posicion
        Productos producto = productos.get(i);

        //Creamos las variables que vamos a necesitar
        TextView txtNombreProducto = view.findViewById(R.id.txtNombreProducto);
        TextView txtCifProveedor = view.findViewById(R.id.txtCifProveedor);
        TextView txtCantidad = view.findViewById(R.id.txtCantidad);

        //Pasamos los datos a las variables
        txtNombreProducto.setText(producto.getNombreProducto());
        txtCifProveedor.setText(producto.getCifProveedor());
        txtCantidad.setText(String.valueOf(producto.getCantidadProducto()));

        //Retornamos la vista
        return view;    }
}
