package com.example.proyectofinal_danielcobo.Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo2.R;

import java.util.List;

public class AdaptadorProvedores extends BaseAdapter {

    //Creamos variables que vamos a necesitar
    Context contexto;
    List<Proveedores> proveedores;
    LayoutInflater inflater;

    public AdaptadorProvedores(Context contexto, List<Proveedores> proveedores) {
        this.contexto = contexto;
        this.proveedores = proveedores;
        inflater = LayoutInflater.from(contexto);
    }
    //Metodos de la clase
    //metodo que toma la cantidad de pedidos
    @Override
    public int getCount() {
        return proveedores.size();
    }
    //Metodo que toma el elemento que se encuentra en dicha posicion
    @Override
    public Object getItem(int i) {
        return i;
    }
    //Tomamos la posicion
    @Override
    public long getItemId(int i) {
        return i;
    }
    //Metodo que crea la vista
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Le pasamos a la lista como tiene que ser cada posicion de ella mediante el estilo
        view = inflater.inflate(R.layout.activity_estilo_proveedores, null);

        Proveedores proveedor = proveedores.get(i);
        //Cada variable cogera el campo que se le pasa por id y dependiendo en la posicion en la que este
        TextView nombreProveedor = view.findViewById(R.id.txtNombreProveedor);
        TextView cifProveedor = view.findViewById(R.id.txtCifProveedor);
        TextView provincia = view.findViewById(R.id.txtProvincia);

        //Pasamos los datos a las variables
        nombreProveedor.setText(proveedor.getNombreProveedor());
        cifProveedor.setText(String.valueOf(proveedor.getCifProveedor()));
        provincia.setText(proveedor.getProvincia());

        //Retornamos la vista
        return view;
    }
}
