package com.example.proyectofinal_danielcobo.Fragments;

import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.io.IOException;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AniadirProveedorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AniadirProveedorFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private EditText editTextCifProveedor;
    private EditText editTextNombreProveedor;
    private AutoCompleteTextView editTextProvincia;
    private Button botonAniadirProveedor;
    Funcionalidad funcionalidad;
    ConexionBD conexionBD;

    public AniadirProveedorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AniadirProveedorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AniadirProveedorFragment newInstance(String param1, String param2) {
        AniadirProveedorFragment fragment = new AniadirProveedorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        conexionBD = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_aniadir_proveedor, container, false);

        SharedPreferences preferencesSesion = getActivity().getSharedPreferences("sesion", getActivity().MODE_PRIVATE);
        String nombreUsuario = preferencesSesion.getString("usuario", null);
        String contrasenia = preferencesSesion.getString("contrasenia", null);

        Usuarios usuario = funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
        if (usuario == null) {
            Toast.makeText(getActivity(), "Usuario no encontrado", Toast.LENGTH_SHORT).show();
            return view;
        }

        editTextCifProveedor=view.findViewById(R.id.etxtCifProveedor);
        editTextNombreProveedor=view.findViewById(R.id.etxtNombreProveedor);
        editTextProvincia=view.findViewById(R.id.etxtProvincia);
        editTextProvincia.setThreshold(1);
        botonAniadirProveedor=view.findViewById(R.id.btnAniadirProveedor);

        String[] provincias = getResources().getStringArray(R.array.ciudades);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_dropdown_item_1line, provincias);
        editTextProvincia.setAdapter(adapter);

        botonAniadirProveedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cifProveedor = editTextCifProveedor.getText().toString().trim();
                String nombreProveedor = editTextNombreProveedor.getText().toString().trim();
                String provincia = editTextProvincia.getText().toString().trim();

                //Mostramos un mensaje para los distintos campos incompletos
                if (cifProveedor.isEmpty() || nombreProveedor.isEmpty() || provincia.isEmpty()) {
                    Toast.makeText(getActivity(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean valido = false;
                //Comprobamos que la provincia se encuentre en la lista de provincias
                for (String p : provincias) {
                    if (p.equals(provincia)) {
                        valido = true;
                        break;
                    }
                }
                if (!valido) {
                    Toast.makeText(getActivity(), "La provincia no es válida", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Comprobamos que el cif cumpla con las caracteristicas de un CIF
                boolean esValido=esCifValido(cifProveedor);
                if(!esValido){
                    Toast.makeText(getActivity(), "El CIF no es válido", Toast.LENGTH_SHORT).show();
                    Toast.makeText(getActivity(), "El CIF debe tener 9 caracteres: una letra inicial, seguida de 7 cifras numéricas y un carácter de control (número o letra)", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Buscamos el proveedor
                Proveedores proveedorExistente = funcionalidad.buscarProveedor(new Proveedores(cifProveedor, nombreProveedor, provincia, usuario.getId()));
                if (proveedorExistente != null) {
                    Toast.makeText(getActivity(), "El Cif del proveedor ya existe", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Creamos el objeto proveedor
                Proveedores nuevoProveedor = new Proveedores(cifProveedor, nombreProveedor, provincia, usuario.getId());
                //Insertamos el proveedor en la base de datos
                long id = 0;
                try {
                    id = funcionalidad.insertarProveedor(nuevoProveedor);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                //Comprobamos si se ha insertado correctamente
                if (id != -1) {
                    Toast.makeText(getActivity(), "Proveedor añadido con éxito", Toast.LENGTH_SHORT).show();
                    editTextCifProveedor.setText("");
                    editTextNombreProveedor.setText("");
                    editTextProvincia.setText("");
                } else {
                    Toast.makeText(getActivity(), "Error al añadir el proveedor", Toast.LENGTH_SHORT).show();
                    editTextCifProveedor.setText("");
                    editTextNombreProveedor.setText("");
                    editTextProvincia.setText("");
                }
            }
        });

        return view;
    }
    public boolean esCifValido(String cif) {
        if (cif == null || cif.length() != 9) return false;

        cif = cif.toUpperCase();

        char letraInicial = cif.charAt(0);
        String numeros = cif.substring(1, 8);
        char control = cif.charAt(8);

        if (!numeros.matches("\\d{7}")) return false;

        int sumaPar = 0;
        int sumaImpar = 0;

        // Recorremos los 7 dígitos centrales
        for (int i = 0; i < numeros.length(); i++) {
            int digito = Character.getNumericValue(numeros.charAt(i));

            if ((i + 1) % 2 == 0) {
                // Posición par
                sumaPar += digito;
            } else {
                // Posición impar
                int doble = digito * 2;
                sumaImpar += (doble > 9) ? doble - 9 : doble;
            }
        }

        int sumaTotal = sumaPar + sumaImpar;
        int digitoControlCalculado = (10 - (sumaTotal % 10)) % 10;

        char controlNumerico = (char) ('0' + digitoControlCalculado);

        String letrasControl = "JABCDEFGHI";
        char controlLetra = letrasControl.charAt(digitoControlCalculado);

        String tiposLetra = "PQRSNW";
        String tiposNumero = "ABEH";

        if (tiposLetra.indexOf(letraInicial) >= 0) {
            return control == controlLetra;
        } else if (tiposNumero.indexOf(letraInicial) >= 0) {
            return control == controlNumerico;
        } else {
            return control == controlNumerico || control == controlLetra;
        }
    }
}