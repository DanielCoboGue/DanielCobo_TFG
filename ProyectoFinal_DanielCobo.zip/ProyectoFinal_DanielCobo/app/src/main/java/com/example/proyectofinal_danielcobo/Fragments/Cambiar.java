package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.MainActivity;
import com.example.proyectofinal_danielcobo.Principales.Registro;
import com.example.proyectofinal_danielcobo2.R;
import com.google.android.material.textfield.TextInputEditText;

public class Cambiar extends AppCompatActivity {
    TextInputEditText tie_nombreUsuarioAntiguo;
    TextInputEditText tip_contraseniaAntiguo;
    TextInputEditText tip_contraseniaNuevo;
    TextInputEditText tip_repetirContrasenia;
    Button btn_cambiar;
    Funcionalidad funcionalidad;
    Registro registro;
    ConexionBD conexion;
    MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cambiar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        String nombreUsuario= getIntent().getStringExtra("nombreUsuario");
        String contrasenia= getIntent().getStringExtra("contrasenia");
        tie_nombreUsuarioAntiguo = findViewById(R.id.tie_nombreUsuarioAntiguo);
        tip_contraseniaAntiguo = findViewById(R.id.tip_contraseniaAntiguo);
        tip_contraseniaNuevo = findViewById(R.id.tip_contraseniaNuevo);
        tip_repetirContrasenia = findViewById(R.id.tip_repetirContrasenia);
        btn_cambiar = findViewById(R.id.btn_cambiar);
        mainActivity=new MainActivity();
        conexion = new ConexionBD(Cambiar.this);
        funcionalidad=new Funcionalidad(conexion.getWritableDatabase());
        registro=new Registro();

        //Cambiamos la contraseña
        btn_cambiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nombreUsuarioAntiguo = tie_nombreUsuarioAntiguo.getText().toString();
                String contraseniaAntigua = tip_contraseniaAntiguo.getText().toString();
                String contraseniaNueva = tip_contraseniaNuevo.getText().toString();
                String repetirContrasenia = tip_repetirContrasenia.getText().toString();

                if (nombreUsuarioAntiguo.isEmpty() || contraseniaAntigua.isEmpty() || contraseniaNueva.isEmpty() || repetirContrasenia.isEmpty()) {
                    Toast.makeText(Cambiar.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }else{

                    Usuarios usuario=funcionalidad.buscarUsuario(new Usuarios(nombreUsuarioAntiguo, contraseniaAntigua, funcionalidad.obtenerNotificacionesUsuario(nombreUsuarioAntiguo), funcionalidad.obtenerProvincia(nombreUsuarioAntiguo)));
                    //Obtenemos el usuario actual
                    Usuarios usuarioActual=funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));

                    if(usuario!=null && usuario.getId()==usuarioActual.getId()){
                        if(registro.comprobar(nombreUsuarioAntiguo, contraseniaNueva, repetirContrasenia, Cambiar.this)){
                            long resultado=funcionalidad.modificar(new Usuarios(nombreUsuarioAntiguo, contraseniaNueva, funcionalidad.obtenerNotificacionesUsuario(nombreUsuarioAntiguo), funcionalidad.obtenerProvincia(nombreUsuarioAntiguo)), nombreUsuarioAntiguo);
                            if (resultado != -1) {
                                tie_nombreUsuarioAntiguo.setText("");
                                tip_contraseniaAntiguo.setText("");
                                tip_contraseniaNuevo.setText("");
                                tip_repetirContrasenia.setText("");
                                Toast.makeText(Cambiar.this, "Usuario modificado correctamente", Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(Cambiar.this, MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Cambiar.this, "No modificado correctamente", Toast.LENGTH_SHORT).show();
                            }
                        }else{
                            tie_nombreUsuarioAntiguo.setText("");
                            tip_contraseniaAntiguo.setText("");
                            tip_contraseniaNuevo.setText("");
                            tip_repetirContrasenia.setText("");
                        }
                    }else{
                        Toast.makeText(Cambiar.this, "El usuario no existe o no es el usuario actual", Toast.LENGTH_SHORT).show();
                        tie_nombreUsuarioAntiguo.setText("");
                        tip_contraseniaAntiguo.setText("");
                        tip_contraseniaNuevo.setText("");
                        tip_repetirContrasenia.setText("");
                    }
                }

            }

        });
    }



}