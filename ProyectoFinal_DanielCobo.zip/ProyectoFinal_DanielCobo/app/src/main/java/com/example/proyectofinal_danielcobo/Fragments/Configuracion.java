package com.example.proyectofinal_danielcobo.Fragments;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.MainActivity;
import com.example.proyectofinal_danielcobo2.R;

public class Configuracion extends PreferenceActivity {
    //Variables de la clase
    Preference ubicacion;
    CheckBoxPreference notificaciones;
    Preference cerrar_sesion;
    Preference cambiar_contrasenia;
    Funcionalidad funcionalidad;
    ConexionBD conexion;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.configuracion);
        //Instanciamos las variables
        conexion=new ConexionBD(Configuracion.this);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
        ubicacion = findPreference("ubicacion");
        cerrar_sesion = findPreference("cerrar_sesion");
        cambiar_contrasenia = findPreference("cambiar_contrasenia");
        notificaciones = (CheckBoxPreference) findPreference("notificaciones");

        //Recuperamos las preferencias
        SharedPreferences preferencesSesion = getSharedPreferences("sesion", MODE_PRIVATE);
        String nombreUsuario = preferencesSesion.getString("usuario", null);
        String contrasenia = preferencesSesion.getString("contrasenia", null);

        //Comprobamos si el usuario tiene notificaciones activadas
        if (funcionalidad.obtenerNotificacionesUsuario(nombreUsuario)) {
            notificaciones.setChecked(true);
        } else {
            notificaciones.setChecked(false);
        }

        //Dirijimos a la pantalla de ubicacion
        ubicacion.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent intent=new Intent(Configuracion.this, Ubicacion.class);
                startActivity(intent);
                return true;
            }
        });

        //Dirijimos a la pantalla de login
        cerrar_sesion.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent intent=new Intent(Configuracion.this, MainActivity.class);
                //Codigo que me evita que alguien despues de cerrar sesion, pueda darle al boton de retroceder y pueda acceder sin meter credenciales.
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
                return true;
            }
        });

        //Dirijimos a la pantalla de cambiar nombre o contraseña
        cambiar_contrasenia.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                Intent intent=new Intent(Configuracion.this, Cambiar.class);
                intent.putExtra("nombreUsuario",nombreUsuario);
                intent.putExtra("contrasenia",contrasenia);
                startActivity(intent);
                return true;            }
        });
        notificaciones.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                boolean valor = notificaciones.isChecked();
                funcionalidad.modificarNotificaciones(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)), valor);
                if (valor) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ActivityCompat.checkSelfPermission(Configuracion.this, android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(Configuracion.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1);
                        }
                    }
                    Toast.makeText(Configuracion.this, "Notificaciones Activadas", Toast.LENGTH_SHORT).show();
                } else {
                    NotificationManagerCompat.from(Configuracion.this).cancelAll();
                    Toast.makeText(Configuracion.this, "Notificaciones Desactivadas", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });
    }
}
