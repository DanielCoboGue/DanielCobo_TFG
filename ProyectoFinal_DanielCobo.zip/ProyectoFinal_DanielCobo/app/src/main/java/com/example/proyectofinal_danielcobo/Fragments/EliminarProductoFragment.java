package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EliminarProductoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EliminarProductoFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private static Funcionalidad funcionalidad;
    private static ConexionBD conexion;
    Spinner spinner;


    public EliminarProductoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EliminarProductoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static EliminarProductoFragment newInstance(String param1, String param2) {
        EliminarProductoFragment fragment = new EliminarProductoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_eliminar_producto, container, false);
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = sharedPreferences.getString("usuario", null);

        if (nombreUsuario == null) {
            Toast.makeText(getActivity(), "Error: Usuario no encontrado en sesión", Toast.LENGTH_SHORT).show();
            return view;
        }

        conexion = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

        spinner = view.findViewById(R.id.spinnerEliminarProducto);

        try {
            ArrayList<Productos> listaProductos = funcionalidad.getProductosPorUsuario(funcionalidad.obtenerId(nombreUsuario));
            ArrayList<String> nombresProductos = new ArrayList<>();
            for (Productos p : listaProductos) {
                nombresProductos.add(p.getNombreProducto() + " (" + funcionalidad.obtenerNombreProveedor(p.getCifProveedor()) + ")");
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, nombresProductos);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "No hay productos", Toast.LENGTH_SHORT).show();
        }

        //Botón eliminar
        Button btnEliminar = view.findViewById(R.id.buttonEliminarProducto);
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    String nombreProductoSeleccionado = null;
                    try {
                        nombreProductoSeleccionado = spinner.getSelectedItem().toString().split("\\(")[0].trim();
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    }
                try {
                    String cifProveedor = funcionalidad.obtenerCifProveedor(nombreProductoSeleccionado, funcionalidad.obtenerId(nombreUsuario));
                    if (cifProveedor == null) {
                        Toast.makeText(getActivity(), "Error al obtener el cif del proveedor", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Productos producto = funcionalidad.obtenerProductoPorProveedor(nombreProductoSeleccionado, cifProveedor);
                    if (producto == null) {
                        Toast.makeText(getActivity(), "Error al obtener el producto", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    long id = funcionalidad.eliminarPedidosProducto(producto.getIdProducto());
                    if (id == -1) {
                        Toast.makeText(getActivity(), "Error al eliminar los pedidos del producto", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    long resultado = funcionalidad.eliminarProducto(producto.getIdProducto());

                    if (resultado != -1) {
                        Toast.makeText(getActivity(), "Producto eliminado correctamente", Toast.LENGTH_SHORT).show();
                        getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new MenosFragment()).commit();
                    } else {
                        Toast.makeText(getActivity(), "Error al eliminar el producto", Toast.LENGTH_SHORT).show();
                    }
                } catch (Exception e) {
                    Toast.makeText(getActivity(), "Error al obtener o eliminar producto", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }
}