package com.example.proyectofinal_danielcobo.Fragments;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.TextView;

import com.example.proyectofinal_danielcobo2.R;

public class InfoPedido extends AppCompatActivity {

    TextView textNombreProducto, textIdPedido, textCifProveedor, textFechaPedido, textDescripcionPedido, textCantidadPedido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_info_pedido);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Inicializamos los campos
        textNombreProducto = findViewById(R.id.textNombreProducto);
        textIdPedido = findViewById(R.id.textIdPedido);
        textCifProveedor = findViewById(R.id.textCifProveedor);
        textCantidadPedido = findViewById(R.id.textCantidadPedido);
        textFechaPedido = findViewById(R.id.textFechaPedido);
        textDescripcionPedido = findViewById(R.id.textDescripcionPedido);

        //Obtenemos los datos del intent
        String nombreProducto = getIntent().getStringExtra("nombreProducto");
        int idPedido = getIntent().getIntExtra("idPedido", 0);
        String cifProveedor = getIntent().getStringExtra("cifProveedor");
        int cantidad = getIntent().getIntExtra("cantidad", 0);
        String fechaPedido = getIntent().getStringExtra("fechaPedido");
        String descripcion = getIntent().getStringExtra("descripcion");

        //Mostramos los datos en los campos
        textNombreProducto.setText(nombreProducto);
        textIdPedido.setText("ID: " + idPedido);
        textCifProveedor.setText("CIF: " + cifProveedor);
        textCantidadPedido.setText("Cantidad: " + cantidad);
        textFechaPedido.setText("Fecha: " + fechaPedido);
        textDescripcionPedido.setText(descripcion);

    }
}