package com.example.proyectofinal_danielcobo.Fragments;

import android.app.PendingIntent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MenosFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MenosFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private EditText editTextNombreProducto;
    private EditText editTextPrecio;
    private EditText editTextCantidad;
    private EditText editTextDescripcion;
    private Button buttonRealizarVenta;
    ConexionBD conexion;
    Funcionalidad funcionalidad;
    PendingIntent pend;
    Toolbar toolbar;
    public String nombreProducto;
    public String cantidad;
    public String nombreUsuario;
    private static final String CHANNEL_ID = "notificacion";
    private static final int NOTIFICATION_ID = 0;
    ImageButton eliminarProveedor;
    ImageButton eliminarProducto;
    ImageButton eliminarPedido;


    public MenosFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment VentaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MenosFragment newInstance(String param1, String param2) {
        MenosFragment fragment = new MenosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        conexion = new ConexionBD(getContext());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_menos, container, false);

        eliminarProveedor=view.findViewById(R.id.eliminarProveedor);
        eliminarProducto=view.findViewById(R.id.eliminarProducto);
        eliminarPedido=view.findViewById(R.id.venderProducto);

        eliminarProveedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new EliminarProveedorFragment()).commit();
            }
        });

        eliminarProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new EliminarProductoFragment()).commit();
            }
        });

        eliminarPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new VentaProductoFragment()).commit();
            }
        });

        return view;
    }

}