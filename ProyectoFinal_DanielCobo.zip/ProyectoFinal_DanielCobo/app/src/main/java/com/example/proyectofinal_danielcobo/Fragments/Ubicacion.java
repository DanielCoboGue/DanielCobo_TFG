package com.example.proyectofinal_danielcobo.Fragments;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

public class Ubicacion extends AppCompatActivity {

    private static final int REQUEST_PERMISSIONS = 1;
    private MapView mapView;
    AutoCompleteTextView autoCompleteTextView;
    Button btnMapa;
    ConexionBD conexion;
    Funcionalidad funcionalidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ubicacion);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Instanciamos las variables
        mapView = findViewById(R.id.mapView);
        autoCompleteTextView = findViewById(R.id.atvCiudad);
        autoCompleteTextView.setThreshold(1);
        btnMapa = findViewById(R.id.btnMapa);
        conexion=new ConexionBD(Ubicacion.this);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

        //Recuperamos las preferencias
        SharedPreferences preferencesSesion = getSharedPreferences("sesion", MODE_PRIVATE);
        String nombreUsuario = preferencesSesion.getString("usuario", null);
        String contrasenia = preferencesSesion.getString("contrasenia", null);

        //Obtenemos el array de strings desde resources
        String[] opciones = getResources().getStringArray(R.array.ciudades);

        //Creamos el adaptador
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Ubicacion.this, android.R.layout.simple_dropdown_item_1line, opciones);

        //Asignamos el adaptador al AutoCompleteTextView
        autoCompleteTextView.setAdapter(adapter);
        autoCompleteTextView.setText(funcionalidad.obtenerProvincia(nombreUsuario));

        //Configuramos el mapa
        Configuration.getInstance().load(Ubicacion.this.getApplicationContext(), this.getSharedPreferences("osmdroid", this.MODE_PRIVATE));
        mapView.setMultiTouchControls(true);
        mapView.getController().setZoom(18.0);

        //Damos funcionalidad al botón
        btnMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pedir permisos
                if (requestPermissions()) {
                    String ciudad = autoCompleteTextView.getText().toString().trim();
                    //Comprobamos que la provincia se encuentre en la lista de provincias
                    boolean valido = false;
                    //Comprobamos que la provincia se encuentre en la lista de provincias
                    for (String p : opciones) {
                        if (p.equals(ciudad)) {
                            valido = true;
                            break;
                        }
                    }
                    if (!valido) {
                        Toast.makeText(Ubicacion.this, "La provincia no es válida", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (ciudad.equalsIgnoreCase("Avila")) {
                        mostrar(40.6566, -4.7003);
                    } else if (ciudad.equalsIgnoreCase("Burgos")) {
                        mostrar(42.3439, -3.6969);
                    } else if (ciudad.equalsIgnoreCase("Leon")) {
                        mostrar(42.5987, -5.5671);
                    } else if (ciudad.equalsIgnoreCase("Palencia")) {
                        mostrar(42.0095, -4.5283);
                    } else if (ciudad.equalsIgnoreCase("Salamanca")) {
                        mostrar(40.9701, -5.6635);
                    } else if (ciudad.equalsIgnoreCase("Segovia")) {
                        mostrar(40.9429, -4.1184);
                    } else if (ciudad.equalsIgnoreCase("Soria")) {
                        mostrar(41.764, -2.4688);
                    } else if (ciudad.equalsIgnoreCase("Valladolid")) {
                        mostrar(41.6528, -4.7245);
                    } else if (ciudad.equalsIgnoreCase("Zamora")) {
                        mostrar(41.5033, -5.7446);
                    } else {
                        Toast.makeText(Ubicacion.this, "Provincia no reconocida", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    //Guardamos la provincia en la base de datos
                    funcionalidad.modificarProvincia(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)), ciudad);
                    Toast.makeText(Ubicacion.this, "Provincia modificada con éxito", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    //Comprobamos los permisos
    private boolean requestPermissions() {
        if (ActivityCompat.checkSelfPermission(Ubicacion.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(Ubicacion.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSIONS);
            return false;
        } else {
            return true;
        }
    }

    //Mostramos el mapa
    private void mostrar(double latitud, double longitud) {

        GeoPoint geoPoint = new GeoPoint(latitud, longitud);
        mapView.getController().setCenter(geoPoint);

        //Añadimos marcador en la posicion exacta
        Marker marker = new Marker(mapView);
        marker.setPosition(geoPoint);
        marker.setTitle("Ubicación Exacta");
        mapView.getOverlays().add(marker);
        mapView.invalidate();

    }
}