package com.example.proyectofinal_danielcobo.Fragments;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link VentaProductoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class VentaProductoFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private EditText editTextPrecio;
    private EditText editTextCantidad;
    private EditText editTextDescripcion;
    private Button buttonRealizarVenta;
    ConexionBD conexion;
    Funcionalidad funcionalidad;
    PendingIntent pend;
    Toolbar toolbar;
    public String nombreProducto;
    public String cantidad;
    public String nombreUsuario;
    private static final String CHANNEL_ID = "notificacion";
    private static final int NOTIFICATION_ID = 0;
    Spinner spinner;
    ArrayList<Productos> listaProductos;

    public VentaProductoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment VentaProductoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static VentaProductoFragment newInstance(String param1, String param2) {
        VentaProductoFragment fragment = new VentaProductoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        conexion = new ConexionBD(getContext());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_venta_producto, container, false);

        SharedPreferences preferencesSesion = getActivity().getSharedPreferences("sesion", getActivity().MODE_PRIVATE);
        nombreUsuario = preferencesSesion.getString("usuario", null);
        String contrasenia = preferencesSesion.getString("contrasenia", null);

        spinner = view.findViewById(R.id.spinnerProductosVenta);

        try {
            listaProductos = funcionalidad.getProductosPorUsuario(funcionalidad.obtenerId(nombreUsuario));
            ArrayList<String> nombresProductos = new ArrayList<>();
            for (Productos p : listaProductos) {
                nombresProductos.add(p.getNombreProducto() + " (" + funcionalidad.obtenerNombreProveedor(p.getCifProveedor()) +" -> "+ p.getCifProveedor()+")");
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, nombresProductos);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(adapter);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "No hay productos", Toast.LENGTH_SHORT).show();
        }

        editTextPrecio = view.findViewById(R.id.etextPrecioVenta);
        editTextCantidad = view.findViewById(R.id.etextCantidadVenta);
        editTextDescripcion = view.findViewById(R.id.etextDescripcionVenta);
        buttonRealizarVenta = view.findViewById(R.id.btnRealizarVenta);

        buttonRealizarVenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Usuarios usuario = funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
                if (usuario == null) {
                    Toast.makeText(getActivity(), "Usuario no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                int usuarioId = usuario.getId();

                //Obtenemos el producto
                Productos producto;

                try{
                    producto = listaProductos.get(spinner.getSelectedItemPosition());
                }catch (IndexOutOfBoundsException e){
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (producto == null) {
                    Toast.makeText(getActivity(), "Producto no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos el producto
                int idProducto = producto.getIdProducto();
                nombreProducto = producto.getNombreProducto();
                String precio = editTextPrecio.getText().toString();
                cantidad = editTextCantidad.getText().toString();
                String descripcion = editTextDescripcion.getText().toString();

                if (nombreProducto.isEmpty() || precio.isEmpty() || cantidad.isEmpty() || descripcion.isEmpty()) {
                    Toast.makeText(getActivity(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos la fecha y hora actual
                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String fechaHora = dateFormat.format(calendar.getTime());

                Ventas venta = new Ventas(usuarioId, idProducto, Double.parseDouble(precio), Integer.parseInt(cantidad), fechaHora, descripcion);

                int nuevaCantidad = producto.getCantidadProducto() - Integer.parseInt(cantidad);
                if (Integer.parseInt(cantidad) <= 0 || Integer.parseInt(precio) <= 0){
                    Toast.makeText(getActivity(), "La cantidad y el precio no pueden ser 0", Toast.LENGTH_SHORT).show();
                    limpiarCampos();
                    return;
                }
                if (nuevaCantidad < 0) {
                    Toast.makeText(getActivity(), "La cantidad resultante de la venta no puede ser negativa", Toast.LENGTH_SHORT).show();
                    limpiarCampos();
                    return;
                } else {
                    long id = funcionalidad.crearVenta(venta);
                    if (id != -1) {
                        Toast.makeText(getActivity(), "Venta realizada con éxito", Toast.LENGTH_SHORT).show();
                        funcionalidad.modificarCantidadProductoPorProveedor(producto, nuevaCantidad);
                        Toast.makeText(getActivity(), "Producto modificado con éxito", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                        Intent intent = new Intent(getActivity(), Toolbar.class);
                        startActivity(intent);
                        setPendingItem();
                        crearNotificacion();
                        lanzarNotificacionVenta();
                    } else {
                        Toast.makeText(getActivity(), "Error al realizar la venta", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                    }
                }

            }
        });

        return view;
    }

    private void limpiarCampos() {
        editTextPrecio.setText("");
        editTextCantidad.setText("");
        editTextDescripcion.setText("");
    }

    private void setPendingItem() {
        Intent intent = new Intent(getActivity(), Toolbar.class);
        pend = PendingIntent.getActivity(getActivity(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    public void crearNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notificacion";
            String description = "Exito";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel canal = new NotificationChannel(CHANNEL_ID, name, importance);
            canal.setDescription(description);
            canal.enableLights(true);
            canal.setLightColor(Color.BLUE);

            NotificationManager manager = (NotificationManager) getActivity().getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(canal);
            }
        }
    }

    public void lanzarNotificacionVenta() {
        NotificationCompat.Builder constructor = new NotificationCompat.Builder(getActivity(), CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Notificación Venta")
                .setContentText("El producto " + nombreProducto + " se ha vendido con éxito, cantidad a restar: " + cantidad)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pend)
                .setAutoCancel(true);

        NotificationManagerCompat noti = NotificationManagerCompat.from(getActivity());
        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                && funcionalidad.obtenerNotificacionesUsuario(nombreUsuario)) {
            noti.notify(NOTIFICATION_ID, constructor.build());
        }
    }
}