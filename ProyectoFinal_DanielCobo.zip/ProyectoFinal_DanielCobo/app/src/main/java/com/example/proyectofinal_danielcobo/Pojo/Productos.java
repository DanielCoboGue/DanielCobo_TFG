package com.example.proyectofinal_danielcobo.Pojo;

public class Productos {
    private int id;
    private String cifProveedor;
    private String nombreProducto;
    private int cantidad;

    public Productos(int id, String cifProveedor,String nombreProducto, int cantidad) {
        this.id = id;
        this.cifProveedor = cifProveedor;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
    }
    public Productos(String cifProveedor, String nombreProducto, int cantidad) {
        this.cifProveedor = cifProveedor;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
    }

    public int getIdProducto() {
        return id;
    }
    public void setIdProducto(int id) {
        this.id = id;
    }
    public String getCifProveedor(){
        return cifProveedor;
    }
    public void setCifProveedor(String cifProveedor){
        this.cifProveedor=cifProveedor;
    }
    public String getNombreProducto(){
        return nombreProducto;
    }
    public void setNombreProducto(String nombreProducto){
        this.nombreProducto=nombreProducto;
    }
    public int getCantidadProducto(){
        return cantidad;
    }
    public void setCantidadProducto(int cantidad) {
        this.cantidad = cantidad;
    }
}
