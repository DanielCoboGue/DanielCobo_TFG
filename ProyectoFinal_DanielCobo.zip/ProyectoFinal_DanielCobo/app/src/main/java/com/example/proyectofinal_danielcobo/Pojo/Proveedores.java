package com.example.proyectofinal_danielcobo.Pojo;

public class Proveedores {
    private String cifProveedor;
    private String nombreProveedor;
    private String provincia;
    private int usuarioId;

    public Proveedores(String cifProveedor) {
        this.cifProveedor = cifProveedor;
    }
    public Proveedores(String cifProveedor, String nombreProveedor, String provincia, int usuarioId) {
        this.cifProveedor = cifProveedor;
        this.nombreProveedor = nombreProveedor;
        this.provincia = provincia;
        this.usuarioId = usuarioId;
    }


    public String getCifProveedor(){
        return cifProveedor;
    }
    public void setCifProveedor(String cifProveedor){
        this.cifProveedor=cifProveedor;
    }
    public String getNombreProveedor(){
        return nombreProveedor;
    }
    public void setNombreProveedor(String nombreProveedor){
        this.nombreProveedor=nombreProveedor;
    }
    public String getProvincia(){
        return provincia;
    }
    public void setProvincia(String provincia){
        this.provincia=provincia;
    }
    public int getUsuarioId(){
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
}
