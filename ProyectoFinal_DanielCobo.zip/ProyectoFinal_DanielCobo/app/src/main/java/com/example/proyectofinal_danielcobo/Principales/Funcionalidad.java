package com.example.proyectofinal_danielcobo.Principales;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.proyectofinal_danielcobo.Pojo.Pedidos;
import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;

import java.io.IOException;
import java.util.ArrayList;

public class Funcionalidad {
    //Creamos la variable de la clase
    private static SQLiteDatabase conexion;
    //Constructor
    public Funcionalidad(SQLiteDatabase conexion){
        this.conexion=conexion;
    }
    //Metodos de la clase
    //Metodo para insertar un usuario
    public long insertar(Usuarios usuario)throws IOException {
        //Creamos un content values para insertar los datos
        //Y lo insertamos en la tabla usuarios
        ContentValues valores=new ContentValues();
        valores.put("nombreUsuario", usuario.getNombreUsuario().toString());
        valores.put("contrasenia", usuario.getContrasenia().toString());

        return conexion.insert("usuarios", null, valores);
    }
    //Metodo para modificar un usuario
    public long modificar(Usuarios usuario, String nombreUsuarioAntiguo){
        ContentValues valores = new ContentValues();
        valores.put("nombreUsuario", usuario.getNombreUsuario());
        valores.put("contrasenia", usuario.getContrasenia());

        return conexion.update("usuarios", valores, "nombreUsuario = ?", new String[]{nombreUsuarioAntiguo});
    }
    //Metodo para obtener el id del usuario
    public int obtenerId(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"id"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        int id = 0;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            cursor.close();
            return id;
        }
        cursor.close();
        return id;
    }
    //Metodo para insertar en la tabla notificaciones
    public long modificarNotificaciones(Usuarios usuario, boolean notificaciones) {
        ContentValues values = new ContentValues();
        if (notificaciones) {
            values.put("notificaciones", "true");
        } else {
            values.put("notificaciones", "false");
        }

        return conexion.update("usuarios", values, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()});
    }
    //Metodo para obtener si las notificaciones estan activadas op no
    public boolean obtenerNotificacionesUsuario(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"notificaciones"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        boolean notificaciones = false;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            String notificacionesUsuario = cursor.getString(cursor.getColumnIndexOrThrow("notificaciones"));
            if (notificacionesUsuario.equals("true")) {
                notificaciones = true;
            }
            cursor.close();
            return notificaciones;
        }
        cursor.close();
        return notificaciones;
    }
    //Obtener usuario por nombre de usuario
    public Usuarios obtenerUsuarioPorNombre(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"*"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        Usuarios usuario = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombreUsuario"));
            String contrasenia = cursor.getString(cursor.getColumnIndexOrThrow("contrasenia"));
            boolean notificaciones = cursor.getInt(cursor.getColumnIndexOrThrow("notificaciones")) == 1;
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            cursor.close();
            return new Usuarios(id, nombre, contrasenia, notificaciones, provincia);
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para obtener la provincia
    public String obtenerProvincia(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"provincia"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        String provincia = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            cursor.close();
        }
        return provincia;
    }
    //Metodo para buscar un usuario
    public Usuarios buscarUsuario(Usuarios usuario) {
        Cursor cursor = conexion.rawQuery("SELECT id, nombreUsuario, contrasenia FROM usuarios WHERE nombreUsuario = ? AND contrasenia = ?",
                new String[]{usuario.getNombreUsuario(), usuario.getContrasenia()});

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            String nombreUsuario = cursor.getString(1);
            String contrasenia = cursor.getString(2);
            cursor.close();
            return new Usuarios(id, nombreUsuario, contrasenia, obtenerNotificacionesUsuario(nombreUsuario), obtenerProvincia(nombreUsuario));
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para modificar la provincia
    public long modificarProvincia(Usuarios usuario, String provincia){
        ContentValues valores = new ContentValues();
        valores.put("provincia", provincia);
        return conexion.update("usuarios", valores, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()});
    }
    //Metodo para obtener el id de un usuario
    public String obtenerNombreUsuario(Usuarios usuario){
        //Creo la variable donde guardo los resultados
        Cursor cursor = conexion.query("usuarios", new String[]{"nombreUsuario"}, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()},
                null, null, null
        );
        String nombreUsuario = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreUsuario = cursor.getString(cursor.getColumnIndexOrThrow("nombreUsuario"));
            cursor.close();
        }
        return nombreUsuario;
    }
    //Metodo para insertar un pedido
    public long insertarPedido(Pedidos pedido){
        ContentValues valores=new ContentValues();
        valores.put("usuarioId", pedido.getUsuarioId());
        valores.put("idProducto", pedido.getIdProducto());
        valores.put("cantidad", pedido.getCantidad());
        valores.put("descripcion", pedido.getDescripcion());
        valores.put("fechaHora", pedido.getFechaHora());

        return conexion.insert("pedidos", null, valores);
    }
    //Metodo para obtener los pedidos de un usuario
    public ArrayList<Pedidos> getPedidos(int usuarioId) {
        ArrayList<Pedidos> listaPedidos = new ArrayList<>();
        Cursor cursor = conexion.query("pedidos", null, "usuarioId = ?", new String[]{String.valueOf(usuarioId)}, null, null, "fechaHora DESC");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int idProducto = cursor.getInt(cursor.getColumnIndexOrThrow("idProducto"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            String fechaHora = cursor.getString(cursor.getColumnIndexOrThrow("fechaHora"));
            String descripcion = cursor.getString(cursor.getColumnIndexOrThrow("descripcion"));
            Pedidos pedido = new Pedidos(id, idUsuario, idProducto, cantidad, fechaHora, descripcion);
            listaPedidos.add(pedido);
        }
        cursor.close();
        return listaPedidos;
    }
    //Metodo para eliminar los pedidos de un proveedor
    public void eliminarPedidosProveedor(String cifProveedor) {
        conexion.execSQL("DELETE FROM pedidos WHERE idProducto IN (SELECT id FROM productos WHERE cifProveedor = ?)", new Object[]{cifProveedor});
    }
    //Metodo para eliminar los pedidos de un producto
    public long eliminarPedidosProducto(int idProducto){
        return conexion.delete("pedidos", "idProducto = ?", new String[]{String.valueOf(idProducto)});
    }
    //Metodo para modificar la cantidad de un producto de proveedor por usuario
    public long modificarCantidadProductoPorProveedor(Productos producto, int nuevaCantidad){
        ContentValues valores = new ContentValues();
        valores.put("cantidad", nuevaCantidad);
        return conexion.update("productos", valores, "cifProveedor = ? AND nombreProducto = ?", new String[]{producto.getCifProveedor(), producto.getNombreProducto()});
    }
    //Metodo para crear una venta
    public long crearVenta(Ventas venta){
        ContentValues valores=new ContentValues();
        valores.put("usuarioId", venta.getUsuarioId());
        valores.put("idProducto", venta.getIdProducto());
        valores.put("precio", venta.getPrecio());
        valores.put("cantidad", venta.getCantidad());
        valores.put("fechaHora", venta.getFechaHora());
        valores.put("descripcion", venta.getDescripcion());
        return conexion.insert("ventas", null, valores);
    }
    //Buscamos un proveedor
    public Proveedores buscarProveedor(Proveedores proveedor) {
        Cursor cursor = conexion.rawQuery("SELECT * FROM proveedores WHERE cifProveedor = ?", new String[]{proveedor.getCifProveedor()});
        if (cursor.moveToFirst()) {
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            cursor.close();
            return new Proveedores(cifProveedor, nombreProveedor, provincia, idUsuario);
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para insertar proveedor
    public long insertarProveedor(Proveedores proveedor)throws IOException {
        ContentValues valores=new ContentValues();
        valores.put("cifProveedor", proveedor.getCifProveedor());
        valores.put("nombreProveedor", proveedor.getNombreProveedor());
        valores.put("provincia", proveedor.getProvincia());
        valores.put("usuarioId", proveedor.getUsuarioId());
        return conexion.insert("proveedores", null, valores);
    }
    //Metodo para obtener los proveedores de un usuario en un arraylist
    public ArrayList<Proveedores> getProveedores(int usuarioId) {
        ArrayList<Proveedores> listaProveedores = new ArrayList<>();
        Cursor cursor = conexion.query("proveedores", null, "usuarioId = ?", new String[]{String.valueOf(usuarioId)}, null, null, null);
        while (cursor.moveToNext()) {
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            Proveedores proveedor = new Proveedores(cifProveedor, nombreProveedor, provincia, idUsuario);
            listaProveedores.add(proveedor);
        }
        cursor.close();
        return listaProveedores;
    }
    //Metodo para eliminar un proveedor
    public long eliminarProveedor(Proveedores proveedor){
        return conexion.delete("proveedores", "cifProveedor = ?", new String[]{proveedor.getCifProveedor()});
    }
    //Insertamos un produto
    public long insertarProducto(Productos producto){
        ContentValues valores=new ContentValues();
        valores.put("cifProveedor", producto.getCifProveedor());
        valores.put("nombreProducto", producto.getNombreProducto());
        valores.put("cantidad", producto.getCantidadProducto());
        return conexion.insert("productos", null, valores);
    }
    //Obtenemos el nombre de producto por su id
    public String obtenerNombreProducto(int idProducto){
        Cursor cursor = conexion.query("productos", new String[]{"nombreProducto"}, "id = ?", new String[]{String.valueOf(idProducto)},
                null, null, null
        );
        String nombreProducto = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreProducto = cursor.getString(cursor.getColumnIndexOrThrow("nombreProducto"));
            cursor.close();
        }
        return nombreProducto;
    }
    //Metodo para eliminar un producto
    public long eliminarProducto(int idProducto){
        return conexion.delete("productos", "id = ?", new String[]{String.valueOf(idProducto)});
    }
    //Obtenemos los productos de los provedores con nuestro id de usuario
    public ArrayList<Productos> getProductosPorUsuario(int usuarioId) {
        ArrayList<Productos> productos = new ArrayList<>();

        String consulta = "SELECT p.id, p.cifProveedor, p.nombreProducto, p.cantidad FROM productos p " +
                "JOIN proveedores pr ON p.cifProveedor = pr.cifProveedor " +
                "WHERE pr.usuarioId = ?";

        Cursor cursor = conexion.rawQuery(consulta, new String[]{String.valueOf(usuarioId)});

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
                String nombreProducto = cursor.getString(cursor.getColumnIndexOrThrow("nombreProducto"));
                int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));

                productos.add(new Productos(id, cifProveedor, nombreProducto, cantidad));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return productos;
    }
    //Metodo para obtener el cif de un proveedor por nombre de producto y id de usuario
    public String obtenerCifProveedor(String nombreProducto, int usuarioId) {
        String cifProveedor = null;
        String consulta = "SELECT p.cifProveedor FROM productos p " +
                "JOIN proveedores pr ON p.cifProveedor = pr.cifProveedor " +
                "WHERE p.nombreProducto = ? AND pr.usuarioId = ?";

        Cursor cursor = conexion.rawQuery(consulta, new String[]{nombreProducto, String.valueOf(usuarioId)});

        if (cursor.moveToFirst()) {
            cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
        }
        cursor.close();
        return cifProveedor;
    }
    //Obtener producto por nombre de producto de un proveedor
    public Productos obtenerProductoPorProveedor(String nombreProducto, String cifProveedor){
        Cursor cursor = conexion.query(
                "productos", new String[]{"*"}, "nombreProducto = ? AND cifProveedor = ?", new String[]{nombreProducto, cifProveedor},
                null, null, null
        );
        Productos producto = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            cursor.close();
            return new Productos(id, cifProveedor, nombreProducto, cantidad);
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para eliminar los productos de un proveedor
    public long eliminarProductosProveedor(String cifProveedor){
        return conexion.delete("productos", "cifProveedor = ?", new String[]{cifProveedor});
    }
    //Obtener nombre provedor por cif del proveedor
    public String obtenerNombreProveedor(String cifProveedor){
        Cursor cursor = conexion.query("proveedores", new String[]{"nombreProveedor"}, "cifProveedor = ?", new String[]{cifProveedor},
                null, null, null
        );
        String nombreProveedor = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            cursor.close();
        }
        return nombreProveedor;
    }

}


