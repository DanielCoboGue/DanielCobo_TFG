package com.example.proyectofinal_danielcobo.Principales;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo2.R;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    //Variables de la clase
    Button btnRegistrarse;
    ImageView imagen;
    Animation aparicion;
    Button btnIniciarSesion;
    TextInputEditText nombreInicioSesion;
    TextInputEditText contraseniaInicioSesion;
    ConexionBD conexion;
    private static Funcionalidad funcionalidad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        conexion = new ConexionBD(MainActivity.this);
        //conexion.onUpgrade(conexion.getWritableDatabase(), 0, 1);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

        //Imagen instanciada
        imagen=findViewById(R.id.imageView);

        btnRegistrarse=findViewById(R.id.btn_registro);

        //Damos funcionalidad al boton de registro
        btnRegistrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //funcionalidad.eliminarUsuarios();
                //Cambiamos a panrtalla registro
                Intent intent= new Intent(MainActivity.this, Registro.class);
                startActivity(intent);
            }
        });
        //Animacion de la imagen
        aparicion= AnimationUtils.loadAnimation(this, R.anim.aparicion);
        imagen.startAnimation(aparicion);
        //Instanciamos las variables


        nombreInicioSesion=findViewById(R.id.tie_nombreUsuarioInicio);
        contraseniaInicioSesion=findViewById(R.id.tip_contraseniaInicio);

        btnIniciarSesion=findViewById(R.id.btn_incioSesion);
        btnIniciarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Comprobamos si el usuario existe
                //Si existe lo enviamos a la pantalla principal
                //Si no existe mostramos un mensaje
                String nombre=nombreInicioSesion.getText().toString().trim();
                String contrasenia=contraseniaInicioSesion.getText().toString().trim();
                if(nombre.isEmpty() || contrasenia.isEmpty()){
                    Toast.makeText(MainActivity.this, "Los campos no pueden estar vacios", Toast.LENGTH_SHORT).show();
                    return;
                }
                Usuarios usuario=comprobarInicio(nombre, contrasenia);
                if(usuario!=null){
                    Intent intent=new Intent(MainActivity.this, Toolbar.class);

                    //Guardamos el usuario en las preferencias
                    SharedPreferences preferences = getSharedPreferences("sesion", MODE_PRIVATE);
                    SharedPreferences.Editor editor = preferences.edit();
                    editor.putString("usuario", nombre);
                    editor.putString("contrasenia", contrasenia);
                    editor.apply();
                    //Pasamos el usuario a la pantalla principal
                    intent.putExtra(String.valueOf(nombreInicioSesion), "nombre");
                    intent.putExtra(String.valueOf(contraseniaInicioSesion), "contrasenia");
                    startActivity(intent);
                }else{
                    Toast.makeText(MainActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

   public static Usuarios comprobarInicio(String nombre, String contrasenia){

       return funcionalidad.buscarUsuario(new Usuarios(nombre, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombre), funcionalidad.obtenerProvincia(nombre)));
    }
 }