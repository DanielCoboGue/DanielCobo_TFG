public class AdaptadorProveedores  {
}
