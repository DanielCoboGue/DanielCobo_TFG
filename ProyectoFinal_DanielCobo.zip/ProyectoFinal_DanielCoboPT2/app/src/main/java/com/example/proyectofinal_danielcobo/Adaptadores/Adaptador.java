package com.example.proyectofinal_danielcobo.Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.proyectofinal_danielcobo.Pojo.Pedidos;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;


import java.util.ArrayList;
import java.util.List;

public class Adaptador extends BaseAdapter {

    //Creamos los atributos que vamos a necesitar
    Context contexto;
    ConexionBD conexion;
    List<Pedidos> pedidos;
    LayoutInflater inflater;
    Funcionalidad funcionalidad;

    //Constructor
    public Adaptador(Context contexto, ArrayList<Pedidos> pedidos) {
        this.contexto = contexto;
        this.pedidos=pedidos;
        inflater = LayoutInflater.from(contexto);
    }
    //Metodos de la clase
    //metodo que toma la cantidad de pedidos
    @Override
    public int getCount() {

        return pedidos.size();
    }
    //Metodo que toma el elemento que se encuentra en dicha posicion
    @Override
    public Object getItem(int i) {

        return pedidos.get(i);
    }
    //Tomamos la posicion
    @Override
    public long getItemId(int i) {

        return i;
    }
    //Metodo que crea la vista
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Inflamos la vista
        view = inflater.inflate(R.layout.activity_estilo, null);

        //Creamos la conexion a la base de datos
        conexion = new ConexionBD(contexto);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

        //Tomamos el pedido de la posicion
        Pedidos pedido = pedidos.get(i);
        //Cada variable cogera el campo que se le pasa por id y dependiendo en la posicion en la que este
        TextView nombreProducto = view.findViewById(R.id.textNombreProducto);
        TextView id = view.findViewById(R.id.txtId);
        TextView cantidad = view.findViewById(R.id.textCantidad);
        TextView fecha = view.findViewById(R.id.textFecha);

        //Asignamos los valores a los atributos
        nombreProducto.setText(funcionalidad.obtenerNombreProducto(pedido.getIdProducto()));
        id.setText(contexto.getString(R.string.txtid)+String.valueOf(pedido.getId()));
        cantidad.setText(contexto.getString(R.string.cantidadVenta)+String.valueOf(pedido.getCantidad()));
        fecha.setText(pedido.getFechaHora());

        //Retornamos la vista
        return view;
    }
}
