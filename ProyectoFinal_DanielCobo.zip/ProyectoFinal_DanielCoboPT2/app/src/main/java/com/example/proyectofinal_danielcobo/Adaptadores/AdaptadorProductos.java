package com.example.proyectofinal_danielcobo.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Fragments.EditarProducto;
import com.example.proyectofinal_danielcobo.Fragments.InfoProducto;
import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo2.R;

import java.util.List;

public class AdaptadorProductos extends BaseAdapter {
    //Creamos variables que vamos a necesitar
    Context contexto;
    List<Productos> productos;
    LayoutInflater inflater;
    ImageButton imagenEditar;
    //Constructor
    public AdaptadorProductos(Context contexto, List<Productos> productos) {
        this.contexto = contexto;
        this.productos = productos;
        inflater = LayoutInflater.from(contexto);

    }

    @Override
    public int getCount() {
        return productos.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Le pasamos a la lista como tiene que ser cada posicion de ella mediante el estilo
        view = inflater.inflate(R.layout.activity_estilo_productos, null);

        //Tomamos el producto que se encuentra en la posicion
        Productos producto = productos.get(i);

        //Creamos las variables que vamos a necesitar
        TextView txtNombreProducto = view.findViewById(R.id.txtNombreProducto);
        TextView txtCifProveedor = view.findViewById(R.id.txtCifProveedor);
        TextView txtCantidad = view.findViewById(R.id.txtCantidad);

        //Pasamos los datos a las variables
        txtNombreProducto.setText(producto.getNombreProducto());
        txtCifProveedor.setText(producto.getCifProveedor());
        txtCantidad.setText(String.valueOf(producto.getCantidadProducto()));

        //Creamos el boton para editar el producto
        imagenEditar = view.findViewById(R.id.btnEditarProducto);
        imagenEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Mostramos un mensaje del producto que se va a editar
                Toast.makeText(contexto, "Producto seleccionado con ID: " + producto.getIdProducto(), Toast.LENGTH_SHORT).show();
                //Pasamos la informacion del producto a la siguiente pantalla
                Intent intent = new Intent(contexto, EditarProducto.class);
                intent.putExtra("idProducto", producto.getIdProducto());
                intent.putExtra("nombreProducto", producto.getNombreProducto());
                intent.putExtra("cifProveedor", producto.getCifProveedor());
                intent.putExtra("cantidadProducto", producto.getCantidadProducto());
                intent.putExtra("precioCompra", producto.getPrecioCompra());
                intent.putExtra("categoria", producto.getCategoria());
                //Iniciamos la actividad
                contexto.startActivity(intent);
            }
        });

        view.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //Abrir InfoProducto
                Intent intent = new Intent(contexto, InfoProducto.class);
                intent.putExtra("nombreProducto", producto.getNombreProducto());
                intent.putExtra("cifProveedor", producto.getCifProveedor());
                intent.putExtra("cantidad", producto.getCantidadProducto());
                intent.putExtra("precioCompra", producto.getPrecioCompra());
                intent.putExtra("categoria", producto.getCategoria());
                contexto.startActivity(intent);
            }
        });

        //Retornamos la vista
        return view;
    }
}
