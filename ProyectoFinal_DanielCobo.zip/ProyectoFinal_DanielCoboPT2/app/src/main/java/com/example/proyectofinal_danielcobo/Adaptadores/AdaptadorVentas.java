package com.example.proyectofinal_danielcobo.Adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.util.List;
import java.util.Locale;

public class AdaptadorVentas extends BaseAdapter {
    //Creamos variables que vamos a necesitar
    Context contexto;
    List<Ventas> ventas;
    LayoutInflater inflater;
    Funcionalidad funcionalidad;
    ConexionBD conexionBD;

    public AdaptadorVentas(Context contexto, List<Ventas> ventas) {
        this.contexto = contexto;
        this.ventas = ventas;
        inflater = LayoutInflater.from(contexto);
    }
    @Override
    public int getCount() {
        return ventas.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        //Le pasamos a la lista como tiene que ser cada posicion de ella mediante el estilo
        view = inflater.inflate(R.layout.activity_estilo_ventas, null);

        //Creamos la conexion a la base de datos
        conexionBD = new ConexionBD(contexto);
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());

        //Tomamos la venta que se encuentra en la posicion
        Ventas venta = ventas.get(i);

        //Creamos las variables que vamos a necesitar
        TextView txtNombreProducto = view.findViewById(R.id.txtNombreProducto);
        TextView txtCantidadPrecio = view.findViewById(R.id.txtCantidadPrecio);
        TextView txtFechaVenta = view.findViewById(R.id.txtFechaVenta);
        TextView txtDescripcionVenta = view.findViewById(R.id.txtDescripcionVenta);

        //Obtenemos el nombre del producto por su id
        String nombreProducto = funcionalidad.obtenerNombreProducto(venta.getIdProducto());

        //Pasamos los datos a las variables
        txtNombreProducto.setText(nombreProducto);
        txtCantidadPrecio.setText(contexto.getString(R.string.cantidadVenta) + venta.getCantidad() + " | " + contexto.getString(R.string.precioVenta) + String.format(Locale.getDefault(), "%.2f", venta.getPrecio()) + " €");
        txtFechaVenta.setText(contexto.getString(R.string.fecha) + venta.getFechaHora());
        txtDescripcionVenta.setText(contexto.getString(R.string.descripcionVentas) + venta.getDescripcion());


        //Retornamos la vista
        return view;
    }
}
