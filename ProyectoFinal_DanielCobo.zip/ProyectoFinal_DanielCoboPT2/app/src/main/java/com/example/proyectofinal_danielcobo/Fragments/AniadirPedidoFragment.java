package com.example.proyectofinal_danielcobo.Fragments;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Pedidos;
import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AniadirPedidoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AniadirPedidoFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private EditText editTextCantidad, editTextDescripcion;
    private Button buttonAniadirPedido;
    private Calendar calendar;
    private Funcionalidad funcionalidad;
    ConexionBD conexion;
    private static final String CHANNEL_ID = "notificacion";
    private static final int NOTIFICATION_ID = 0;
    PendingIntent pend;
    public String nombreProducto;
    String cantidadPedido;
    String descripcionPedido;
    public String nombreUsuario;
    AutoCompleteTextView actvProductos;

    public AniadirPedidoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AniadirPedidoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AniadirPedidoFragment newInstance(String param1, String param2) {
        AniadirPedidoFragment fragment = new AniadirPedidoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_aniadir_pedido, container, false);

        //Codigo que nos impide volver con el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        //Creamos la conexion a la base de datos
        conexion = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());

        //Obtenemos el nombre del usuario y su contraseña
        SharedPreferences preferencias = getActivity().getSharedPreferences("sesion", getActivity().MODE_PRIVATE);
        nombreUsuario = preferencias.getString("usuario", null);
        String contrasenia = preferencias.getString("contrasenia", null);

        //Inicializamos los campos
        actvProductos = view.findViewById(R.id.actvProductos);
        editTextDescripcion = view.findViewById(R.id.editTextDescripcion);
        buttonAniadirPedido = view.findViewById(R.id.buttonAniadirPedido);
        editTextCantidad = view.findViewById(R.id.editTextCantidad);

        //Llenamos el array de productos
        ArrayList<Productos> listaProductos = funcionalidad.getProductosPorUsuario(funcionalidad.obtenerId(nombreUsuario));
        ArrayList<String> nombresProductos = new ArrayList<>();
        for (Productos p : listaProductos) {
            nombresProductos.add(p.getNombreProducto() + " (" + p.getCifProveedor() + ")");
        }
        //Creamos el adaptador para el autocomplete
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, nombresProductos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Asignamos el adaptador al autocomplete
        actvProductos.setAdapter(adapter);
        actvProductos.setThreshold(1);
        //Añadimos el escuchador al boton
        buttonAniadirPedido.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Comprobamos que los campos no esten vacios
                cantidadPedido=editTextCantidad.getText().toString().trim();
                descripcionPedido = editTextDescripcion.getText().toString().trim();

                if (cantidadPedido.isEmpty() || descripcionPedido.isEmpty()) {
                    Toast.makeText(getActivity(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Comprobamos que el producto seleccionado existe
                String item;
                try{
                    item = actvProductos.getText().toString().trim();
                }catch (NullPointerException e){
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    return;
                }
                String cifProveedor=null;
                try{
                    //Obtenemos el nombre del producto y el cif del proveedor
                    nombreProducto = item.split("\\(")[0].trim();
                    cifProveedor = item.split("\\(")[1].replace(")", "").trim();
                }catch (ArrayIndexOutOfBoundsException e){
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos el producto
                Productos producto = funcionalidad.obtenerProductoPorProveedor(nombreProducto, cifProveedor, funcionalidad.obtenerId(nombreUsuario));
                //Comprobamos que el producto existe
                if (producto == null) {
                    Toast.makeText(getActivity(), "Producto no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos la fecha y hora actual
                calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String fechaHora = dateFormat.format(calendar.getTime());

                try {
                    int cantidad = Integer.parseInt(cantidadPedido);

                    //Comprobamos que los campos no esten vacios o sean 0
                    if (descripcionPedido.isEmpty() || nombreProducto.isEmpty() || cantidadPedido.isEmpty() || cantidad <= 0) {
                        Toast.makeText(getActivity(), "Todos los campos son obligatorios y mayor que 0", Toast.LENGTH_SHORT).show();
                        return;
                    }

                } catch (NumberFormatException e) {
                    Toast.makeText(getActivity(), "Introduce una cantidad válida", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Comprobamos que el usuario existe
                Usuarios usuario = funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
                if (usuario == null) {
                    Toast.makeText(getActivity(), "Usuario no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                int usuarioId = usuario.getId();

                //Obtenemos el id del producto que queremos meter
                int idProducto = producto.getIdProducto();
                //Comprobamos que la cantidad del producto no sea 0
                int nuevaCantidad = producto.getCantidadProducto() + Integer.parseInt(cantidadPedido);
                if (nuevaCantidad < 0) {
                    Toast.makeText(getActivity(), "La cantidad resultante del pedido no puede ser <= 0", Toast.LENGTH_SHORT).show();
                    limpiarCampos();
                    return;
                } else {
                    //Añadimos el pedido
                    Pedidos nuevoPedido = new Pedidos(usuarioId, idProducto, Integer.parseInt(cantidadPedido), fechaHora, descripcionPedido);
                    long id = funcionalidad.insertarPedido(nuevoPedido, usuarioId);
                    //Comprobamos que se ha añadido el pedido
                    if (id != -1) {
                        Toast.makeText(getActivity(), "Pedido añadido con éxito", Toast.LENGTH_SHORT).show();
                        funcionalidad.modificarCantidadProductoPorProveedor(producto,nuevaCantidad);
                        limpiarCampos();
                        startActivity(new Intent(getActivity(), Toolbar.class));
                    } else {
                        Toast.makeText(getActivity(), "Error al añadir el pedido", Toast.LENGTH_SHORT).show();
                        limpiarCampos();
                    }
                }

            }
        });

        return view;
    }
    //Metodo que limpia los campos
    private void limpiarCampos() {
        actvProductos.setText("");
        editTextDescripcion.setText("");
        editTextCantidad.setText("");
    }
}