package com.example.proyectofinal_danielcobo.Fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link AniadirProductoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AniadirProductoFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private AutoCompleteTextView actvCifProveedor;
    private EditText etxtNombreProducto;
    private Button btnAniadirProducto;
    private Funcionalidad funcionalidad;
    private ConexionBD conexionBD;
    private ArrayList<Proveedores> listaProveedores;
    private Spinner spnCategoria;
    private EditText precioCompra;

    public AniadirProductoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AniadirProductoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static AniadirProductoFragment newInstance(String param1, String param2) {
        AniadirProductoFragment fragment = new AniadirProductoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        conexionBD = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_aniadir_producto, container, false);

        //Codigo que nos impide volver con el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        //Obtenemos el nombre del usuario y su contraseña
        SharedPreferences preferences = getActivity().getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = preferences.getString("usuario", null);
        String contrasenia = preferences.getString("contrasenia", null);

        Usuarios usuario = funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
        //Inicializamos los campos
        actvCifProveedor = view.findViewById(R.id.actvCifProveedor);
        etxtNombreProducto = view.findViewById(R.id.etxtNombreProducto);
        spnCategoria = view.findViewById(R.id.spnCategoria);
        precioCompra = view.findViewById(R.id.etxtPrecioCompra);
        btnAniadirProducto = view.findViewById(R.id.btnAniadirProducto);
        //Llenamos el array de proveedores
        ArrayList<Proveedores> listaProveedores = funcionalidad.getProveedores(funcionalidad.obtenerId(nombreUsuario));
        ArrayList<String> cifs = new ArrayList<>();
        for (Proveedores p : listaProveedores) {
            cifs.add(p.getCifProveedor() + " (" + p.getNombreProveedor() + ")");
        }
        //Creamos el adaptador para el autocomplete
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_dropdown_item_1line, cifs);
        actvCifProveedor.setAdapter(adapter);
        actvCifProveedor.setThreshold(1);

        //LLenamos el array de categorias
        String[] categorias = getResources().getStringArray(R.array.categorias);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_dropdown_item_1line, categorias);
        spnCategoria.setAdapter(adapter2);

        //Añadimos el escuchador al boton
        btnAniadirProducto.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  //Obtenemos el cif del proveedor
                  String cif;
                  try {
                      cif = actvCifProveedor.getText().toString().split("\\(")[0].trim();
                  }catch (NullPointerException e){
                      Toast.makeText(getContext(), "No se ha seleccionado un proveedor", Toast.LENGTH_SHORT).show();
                      return;
                  }
                  //Obtenemos el nombre del producto
                  String nombreProducto = etxtNombreProducto.getText().toString();
                  //Obtenemos la categoria del producto
                  String categoria = spnCategoria.getSelectedItem().toString();
                  //Obtenemos el precio de compra
                  if(precioCompra.getText().toString().isEmpty() || precioCompra.getText().toString().equals("0")){
                      Toast.makeText(getContext(), "Todos los campos son obligatorios y distintos de 0", Toast.LENGTH_SHORT).show();
                      return;
                  }
                  double precioCompraProducto;
                  try {
                      precioCompraProducto = Double.parseDouble(precioCompra.getText().toString());

                  }catch (NumberFormatException e){
                      Toast.makeText(getContext(), "El precio de compra debe ser un número válido", Toast.LENGTH_SHORT).show();
                      return;
                  }
                  //Comprobamos que los campos no esten vacios
                  if (cif.isEmpty() || nombreProducto.isEmpty() || categoria.isEmpty() || String.valueOf(precioCompraProducto).isEmpty()) {
                      Toast.makeText(getContext(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                      return;
                  }

                  try {
                      //Comprobamos que el proveedor existe
                      Proveedores proveedor = funcionalidad.buscarProveedor(new Proveedores(cif), funcionalidad.obtenerId(nombreUsuario));
                      if (proveedor == null) {
                          Toast.makeText(getContext(), "El proveedor no existe", Toast.LENGTH_SHORT).show();
                          return;
                      }else{
                          //Comprobamos que el proveedor esté disponible
                          if(proveedor.getDisponible()==0){
                              Toast.makeText(getContext(), "El proveedor no está disponible", Toast.LENGTH_SHORT).show();
                              return;
                          }
                      }

                      if(precioCompra.getText().toString().isEmpty() || precioCompra.getText().toString().equals("0")){
                          Toast.makeText(getContext(), "El precio de compra no puede ser 0", Toast.LENGTH_SHORT).show();
                          return;
                      }

                      Productos producto = funcionalidad.obtenerProductoPorProveedor(nombreProducto, cif, funcionalidad.obtenerId(nombreUsuario));
                      if (producto != null) {
                          //Comprobamos que el producto esté disponible
                          if (producto.getDisponible() == 1) {
                              //El producto ya existe en el proveedor
                              Toast.makeText(getContext(), "El producto ya existe en el proveedor", Toast.LENGTH_SHORT).show();
                              return;
                          } else {
                              //Preguntamos al usuario si quiere reactivarlo
                              new AlertDialog.Builder(getContext())
                                      .setTitle("Producto existente")
                                      .setMessage("El producto ya existe pero está inactivo. ¿Quieres reactivarlo?")
                                      .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                                          @Override
                                          public void onClick(DialogInterface dialog, int which) {
                                              funcionalidad.modificarDisponibilidadProducto(producto,1);
                                              Toast.makeText(getContext(), "Producto reactivado con éxito", Toast.LENGTH_SHORT).show();
                                              actvCifProveedor.setText("");
                                              etxtNombreProducto.setText("");
                                              precioCompra.setText("");
                                          }
                                      })
                                      .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                          @Override
                                          public void onClick(DialogInterface dialog, int which) {
                                              dialog.dismiss();
                                          }
                                      })
                                      .show();
                              return;
                          }
                      }
                      //Obtenemos el id del usuario
                      int idUsuario = funcionalidad.obtenerId(nombreUsuario);

                      //Creamos el nuevo producto
                      Productos nuevoProducto = new Productos(cif, nombreProducto, 0, 1, precioCompraProducto, categoria, idUsuario);
                      //Insertamos el nuevo producto
                      long id = funcionalidad.insertarProducto(nuevoProducto, idUsuario);
                      //Comprobamos que se ha insertado el producto
                      if (id != -1) {
                          Toast.makeText(getContext(), "Producto insertado con éxito", Toast.LENGTH_SHORT).show();
                          actvCifProveedor.setText("");
                          etxtNombreProducto.setText("");
                          precioCompra.setText("");
                      } else {
                          Toast.makeText(getContext(), "Error al insertar el producto", Toast.LENGTH_SHORT).show();
                      }
                  } catch (NumberFormatException e) {
                      Toast.makeText(getContext(), "La cantidad debe ser un número válido", Toast.LENGTH_SHORT).show();
                  }
              }
        });

        return view;
    }
}