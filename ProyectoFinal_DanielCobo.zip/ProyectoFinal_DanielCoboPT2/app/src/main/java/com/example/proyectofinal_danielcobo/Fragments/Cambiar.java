package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Principales.MainActivity;
import com.example.proyectofinal_danielcobo.Principales.Registro;
import com.example.proyectofinal_danielcobo2.R;
import com.google.android.material.textfield.TextInputEditText;

public class Cambiar extends AppCompatActivity {
    TextInputEditText tip_contraseniaAntiguo;
    TextInputEditText tip_contraseniaNuevo;
    TextInputEditText tip_repetirContrasenia;
    Button btn_cambiar;
    Funcionalidad funcionalidad;
    ConexionBD conexion;
    MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cambiar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Obtenemos los datos del usuario
        String nombreUsuario= getIntent().getStringExtra("nombreUsuario");
        String contrasenia= getIntent().getStringExtra("contrasenia");
        //Inicializamos los campos
        tip_contraseniaAntiguo = findViewById(R.id.tip_contraseniaAntiguo);
        tip_contraseniaNuevo = findViewById(R.id.tip_contraseniaNuevo);
        tip_repetirContrasenia = findViewById(R.id.tip_repetirContrasenia);
        btn_cambiar = findViewById(R.id.btn_cambiar);
        //Inicializamos las clases
        conexion = new ConexionBD(Cambiar.this);
        funcionalidad=new Funcionalidad(conexion.getWritableDatabase());

        //Cambiamos la contraseña
        btn_cambiar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Obtenemos los datos de los campos
                String contraseniaAntigua = tip_contraseniaAntiguo.getText().toString();
                String contraseniaNueva = tip_contraseniaNuevo.getText().toString();
                String repetirContrasenia = tip_repetirContrasenia.getText().toString();
                //Comprobamos que los campos no esten vacios
                if (contraseniaAntigua.isEmpty() || contraseniaNueva.isEmpty() || repetirContrasenia.isEmpty()) {
                    Toast.makeText(Cambiar.this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                }else{
                    //Modificamos la contraseña antigua a MD5 para poder comprobarla
                    String contraseniaAntiguaEncriptada=Registro.md5(contraseniaAntigua);
                    //Obtenemos el usuario antiguo
                    Usuarios usuario=funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contraseniaAntiguaEncriptada, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
                    //Obtenemos el usuario actual
                    Usuarios usuarioActual=funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));

                    if(usuario!=null && usuario.getId()==usuarioActual.getId()){
                        if(Registro.comprobar(contraseniaNueva, repetirContrasenia, Cambiar.this)){
                            //Modificamos la contraseña
                            String contraseniaEncriptada=Registro.md5(contraseniaNueva);
                            //Modificamos el usuario
                            long resultado=funcionalidad.modificar(new Usuarios(nombreUsuario, contraseniaEncriptada, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)), nombreUsuario);
                            //Comprobamos que se haya modificado correctamente
                            if (resultado != -1) {
                                tip_contraseniaAntiguo.setText("");
                                tip_contraseniaNuevo.setText("");
                                tip_repetirContrasenia.setText("");
                                Toast.makeText(Cambiar.this, "Usuario modificado correctamente", Toast.LENGTH_SHORT).show();
                                Intent intent=new Intent(Cambiar.this, MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Cambiar.this, "Usuario no modificado correctamente", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }else{
                        Toast.makeText(Cambiar.this, "El usuario no existe o no es el usuario actual", Toast.LENGTH_SHORT).show();
                    }
                }

            }

        });
    }



}