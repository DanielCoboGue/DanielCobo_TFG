package com.example.proyectofinal_danielcobo.Fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.util.ArrayList;

public class EditarProducto extends AppCompatActivity {
    EditText etxtNombreProducto;
    AutoCompleteTextView actvCifProveedor;
    Button btnEditarProducto;
    ConexionBD conexionBD;
    Funcionalidad funcionalidad;
    int productoID;
    Productos productoActual;
    EditText precioCompra;
    Spinner categorias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar_producto);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.activity_editar_producto), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Inicializamos la base de datos
        conexionBD = new ConexionBD(EditarProducto.this);
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());
        //Obtenemos los datos del usuario
        SharedPreferences preferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = preferences.getString("usuario", null);
        int idUsuario = funcionalidad.obtenerId(nombreUsuario);

        //Inicializamos los campos
        etxtNombreProducto = findViewById(R.id.etxtNombreProducto);
        actvCifProveedor = findViewById(R.id.actvCifProveedor);
        precioCompra = findViewById(R.id.precioCompra);
        categorias = findViewById(R.id.spnCategoria);
        btnEditarProducto = findViewById(R.id.btnAniadirProducto);

        //Obtenemos los datos del producto
        String nombreProducto = getIntent().getStringExtra("nombreProducto");
        String cifProveedor = getIntent().getStringExtra("cifProveedor");
        int cantidadProducto = getIntent().getIntExtra("cantidadProducto", 0);
        productoID = getIntent().getIntExtra("idProducto", 0);
        //Creamos el producto actual
        int disponible = funcionalidad.obtenerProductoDisponible(productoID);
        double precioCompraProducto = funcionalidad.obtenerPrecioCompra(nombreProducto, cifProveedor, idUsuario);
        String categoriaProducto = funcionalidad.obtenerCategoria(nombreProducto, cifProveedor, idUsuario);
        productoActual = new Productos(productoID, nombreProducto, cifProveedor, cantidadProducto, disponible, precioCompraProducto, categoriaProducto, idUsuario);
        //Mostramos los datos del producto
        etxtNombreProducto.setText(nombreProducto);
        actvCifProveedor.setText(cifProveedor);
        precioCompra.setText(String.valueOf(precioCompraProducto));

        //Obtenemos la lista de proveedores
        ArrayList<Proveedores> listaProveedores = funcionalidad.getProveedores(funcionalidad.obtenerId(nombreUsuario));
        ArrayList<String> cifs = new ArrayList<>();
        for (Proveedores p : listaProveedores) {
            cifs.add(p.getCifProveedor());
        }
        //Creamos el adaptador para el autocompletar
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, cifs);
        actvCifProveedor.setAdapter(adapter);
        actvCifProveedor.setThreshold(1);

        //Creamos el adaptador para el spinner
        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.categorias));
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorias.setAdapter(adapter2);
        categorias.setSelection(adapter2.getPosition(categoriaProducto));

        //Establecemos el boton para editar el producto
        btnEditarProducto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Obtenemos los datos nuevos del producto
                String nombreProductoNuevo = etxtNombreProducto.getText().toString();
                double precioCompraNuevo;
                String categoria = categorias.getSelectedItem().toString();
                String cifProveedorNuevo;

                try {
                    //Obtenemos el cif del proveedor
                    cifProveedorNuevo = actvCifProveedor.getText().toString();

                    //Comprobamos que el cif cumpla con las caracteristicas de un CIF
                    if(!cifProveedor.equals(cifProveedorNuevo)){
                        //Buscamos el proveedor
                        Proveedores proveedorExistente = funcionalidad.buscarProveedorPorCif(cifProveedorNuevo, idUsuario);
                        if (proveedorExistente == null) {
                            Toast.makeText(EditarProducto.this, "El proveedor no existe", Toast.LENGTH_SHORT).show();
                            return;
                        }else{
                            //observo si ese cif esta disponible
                            if(proveedorExistente.getDisponible()==0){
                                Toast.makeText(EditarProducto.this, "El proveedor no está disponible", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        }
                    }
                } catch (Exception e) {
                    Toast.makeText(EditarProducto.this, "Debes seleccionar un proveedor válido", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos que el precio nuevo sea un numero
                try{
                    precioCompraNuevo = Double.parseDouble(precioCompra.getText().toString());
                }catch (NumberFormatException e){
                    Toast.makeText(EditarProducto.this, "El precio de compra debe ser un número válido", Toast.LENGTH_SHORT).show();
                    return;

                }
                //Comprobamos que los campos no esten vacios
                if (nombreProductoNuevo.isEmpty() || cifProveedorNuevo.isEmpty() || String.valueOf(precioCompraNuevo).isEmpty() || categoria.isEmpty()) {
                    Toast.makeText(EditarProducto.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos que los campos no sean iguales a los anteriores
                if(cifProveedor.equals(cifProveedorNuevo) && nombreProducto.equals(nombreProductoNuevo) && precioCompraProducto == precioCompraNuevo && categoria.equals(categoriaProducto)){
                    Toast.makeText(EditarProducto.this, "No has realizado ningún cambio", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos el precio de compra
                if (precioCompraNuevo <= 0) {
                    Toast.makeText(EditarProducto.this, "El precio de compra debe ser mayor que 0", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Verificamos si existe un producto con ese proveedor y nombre
                Productos existente = funcionalidad.obtenerProductoPorProveedor(nombreProductoNuevo, cifProveedorNuevo, idUsuario);
                //Comprobamos si el producto ya existe
                if (existente != null && existente.getIdProducto() != productoID) {
                    //Comprobamos si el producto esta disponible
                    if (existente.getDisponible() == 1) {
                        Toast.makeText(EditarProducto.this, "El producto ya existe", Toast.LENGTH_SHORT).show();
                        return;
                    } else {
                        //Si el producto esta inactivo, solicitamos reactivarlo
                        new AlertDialog.Builder(EditarProducto.this)
                                .setTitle("Producto existente inactivo")
                                .setMessage("El producto ya existe pero está inactivo. ¿Quieres reactivarlo?")
                                .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        funcionalidad.modificarDisponibilidadProducto(existente,1);
                                        Toast.makeText(EditarProducto.this, "Producto reactivado con éxito", Toast.LENGTH_SHORT).show();
                                        finish();
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                })
                                .show();
                        return;
                    }
                }
                //Modificamos el producto
                long filas = funcionalidad.editarProducto(productoActual, nombreProductoNuevo, cifProveedorNuevo, precioCompraNuevo, categoria);
                //Comprobamos que se haya modificado correctamente
                if (filas == -1) {
                    Toast.makeText(EditarProducto.this, "Error al editar el producto", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(EditarProducto.this, "Producto editado correctamente", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditarProducto.this, Toolbar.class);
                    startActivity(intent);

                }
            }
        });
    }
}