package com.example.proyectofinal_danielcobo.Fragments;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

public class EditarProveedor extends AppCompatActivity {

    EditText etxtNombreProveedor;
    TextView tvCifProveedor;
    Spinner spinnerProvincia;
    Button btnEditarProveedor;
    ConexionBD conexionBD;
    Funcionalidad funcionalidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar_proveedor);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.activity_editar_proveedor), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Inicializamos la base de datos
        conexionBD = new ConexionBD(EditarProveedor.this);
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());

        //Obtenemos los datos del usuario
        SharedPreferences sharedPreferences = getSharedPreferences("sesion", MODE_PRIVATE);
        String nombreUsuario = sharedPreferences.getString("usuario", "");

        //Inicializamos los campos
        etxtNombreProveedor = findViewById(R.id.etxtNombreProveedor);
        tvCifProveedor = findViewById(R.id.tvCifProveedor);
        spinnerProvincia = findViewById(R.id.spinnerProvincia);
        btnEditarProveedor = findViewById(R.id.btnEditarProveedor);

        //Obtenemos los datos del proveedor
        String nombreProveedor = getIntent().getStringExtra("nombreProveedor");
        String cifProveedor = getIntent().getStringExtra("cifProveedor");
        String provincia = getIntent().getStringExtra("provincia");

        //Mostramos los datos del proveedor
        etxtNombreProveedor.setText(nombreProveedor);
        tvCifProveedor.setText(getResources().getString(R.string.cifProveedorEstilo) + cifProveedor);

        //Creamos el adaptador para el spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.ciudades));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProvincia.setAdapter(adapter);

        spinnerProvincia.setSelection(adapter.getPosition(provincia));

        //Establecemos el boton para editar el proveedor
        btnEditarProveedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Obtenemos los datos nuevos del proveedor
                String nombreProveedorNuevo = etxtNombreProveedor.getText().toString();
                String provinciaNueva = spinnerProvincia.getSelectedItem().toString();

                //Comprobamos que los campos no esten vacios
                if (nombreProveedorNuevo.isEmpty() || provinciaNueva.isEmpty()) {
                    Toast.makeText(EditarProveedor.this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos que los campos no sean iguales a los anteriores
                if(nombreProveedor.equals(nombreProveedorNuevo) && provincia.equals(provinciaNueva)){
                    Toast.makeText(EditarProveedor.this, "No has realizado ningún cambio", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Modificamos el proveedor
                long filas = funcionalidad.editarProveedor(new Proveedores(cifProveedor, nombreProveedor, provincia, funcionalidad.obtenerId(nombreUsuario), funcionalidad.obtenerProveedorDisponible(cifProveedor)), nombreProveedorNuevo, provinciaNueva);
                //Comprobamos que se haya modificado correctamente
                if (filas == -1) {
                    Toast.makeText(EditarProveedor.this, "Error al editar el proveedor", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(EditarProveedor.this, "Proveedor editado correctamente", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditarProveedor.this, Toolbar.class);
                    startActivity(intent);
                }


            }
        });

    }

}