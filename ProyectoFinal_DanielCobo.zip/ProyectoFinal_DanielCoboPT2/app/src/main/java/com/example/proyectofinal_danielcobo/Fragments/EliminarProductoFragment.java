package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EliminarProductoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EliminarProductoFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private static Funcionalidad funcionalidad;
    private static ConexionBD conexion;
    AutoCompleteTextView actvProductos;


    public EliminarProductoFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EliminarProductoFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static EliminarProductoFragment newInstance(String param1, String param2) {
        EliminarProductoFragment fragment = new EliminarProductoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_eliminar_producto, container, false);

        //Codigo que nos impide volver con el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        //Obtenemos los datos del usuario
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = sharedPreferences.getString("usuario", null);

        //Comprobamos que el usuario exista
        if (nombreUsuario == null) {
            Toast.makeText(getActivity(), "Error: Usuario no encontrado en sesión", Toast.LENGTH_SHORT).show();
            return view;
        }

        //Inicializamos la base de datos
        conexion = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
        //Inicializamos el autocompletar
        actvProductos = view.findViewById(R.id.actvNombreProducto);

        try {
            //Obtenemos los productos del usuario
            ArrayList<Productos> listaProductos = funcionalidad.getProductosPorUsuario(funcionalidad.obtenerId(nombreUsuario));
            ArrayList<String> nombresProductos = new ArrayList<>();
            for (Productos p : listaProductos) {
                nombresProductos.add(p.getNombreProducto() + " (" + funcionalidad.obtenerNombreProveedor(p.getCifProveedor()) + ")");
            }
            //Creamos el adaptador para el autocompletar
            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, nombresProductos);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            actvProductos.setAdapter(adapter);
            actvProductos.setThreshold(1);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "No hay productos", Toast.LENGTH_SHORT).show();
        }

        //Botón eliminar
        Button btnEliminar = view.findViewById(R.id.buttonEliminarProducto);
        btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Obtenemos el nombre del producto
                String nombreProductoSeleccionado = actvProductos.getText().toString().split("\\(")[0].trim();
                if (nombreProductoSeleccionado.isEmpty()) {
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto valido", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    //Obtenemos el cif del proveedor
                    String cifProveedor = funcionalidad.obtenerCifProveedor(nombreProductoSeleccionado, funcionalidad.obtenerId(nombreUsuario));
                    if (cifProveedor == null) {
                        Toast.makeText(getActivity(), "Producto no encontrado", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    //Obtenemos el producto
                    Productos producto = funcionalidad.obtenerProductoPorProveedor(nombreProductoSeleccionado, cifProveedor, funcionalidad.obtenerId(nombreUsuario));
                    if (producto == null) {
                        Toast.makeText(getActivity(), "Error al obtener el producto", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Toast.makeText(getActivity(), "Producto = "+producto.getDisponible(), Toast.LENGTH_SHORT).show();
                    //Modificamos la disponibilidad a 0
                    if(producto.getDisponible()==1){
                        long resultado = funcionalidad.modificarDisponibilidadProducto(producto, 0);
                        if (resultado == -1) {
                            Toast.makeText(getActivity(), "Error al modificar la disponibilidad del producto", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Toast.makeText(getActivity(), "Producto eliminado", Toast.LENGTH_SHORT).show();
                        actvProductos.setText("");
                        Intent intent=new Intent(getActivity(), Toolbar.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(getActivity(), "Producto no disponible", Toast.LENGTH_SHORT).show();
                    }

                } catch (Exception e) {
                    Toast.makeText(getActivity(), "Error al obtener o eliminar producto", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return view;
    }
}