package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link EliminarProveedorFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class EliminarProveedorFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private List<Proveedores> listaProveedores;
    private AutoCompleteTextView actvCifProveedor;
    private Button botonAniadirProveedor;
    Funcionalidad funcionalidad;
    ConexionBD conexion;

    public EliminarProveedorFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment EliminarProveedorFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static EliminarProveedorFragment newInstance(String param1, String param2) {
        EliminarProveedorFragment fragment = new EliminarProveedorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        conexion = new ConexionBD(getContext());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_eliminar_proveedor, container, false);

        //Codigo que nos impide volver con el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        //Obtenemos los datos del usuario
        SharedPreferences preferencias = getActivity().getSharedPreferences("sesion", getActivity().MODE_PRIVATE);
        String nombreUsuario = preferencias.getString("usuario", null);

        //Cargamos el spinner con los nombres de los proveedores
        actvCifProveedor = view.findViewById(R.id.actvCifProveedor);
        //Obtenemos los proveedores del usuario
        listaProveedores = funcionalidad.getProveedores(funcionalidad.obtenerId(nombreUsuario));
        //Creamos el adaptador para el autocomplete
        ArrayList<String> nombresProveedores = new ArrayList<>();
        for (Proveedores p : listaProveedores) {
            nombresProveedores.add(p.getNombreProveedor() + " (" + p.getCifProveedor() + ")");
        }
        //Creamos el adaptador para el autocomplete
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                getContext(), android.R.layout.simple_spinner_item, nombresProveedores
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        actvCifProveedor.setAdapter(adapter);
        actvCifProveedor.setThreshold(1);
        //Boton para eliminar
        botonAniadirProveedor=view.findViewById(R.id.btnAniadirProveedor);
        botonAniadirProveedor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cifProveedor = "";
                try {
                    //Obtenemos el cif del proveedor
                    cifProveedor = actvCifProveedor.getText().toString().split("\\(")[1].split("\\)")[0];
                } catch (ArrayIndexOutOfBoundsException e) {
                    Toast.makeText(getActivity(), "No se ha seleccionado un proveedor valido", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Buscamos el proveedor
                Proveedores proveedorExistente = funcionalidad.buscarProveedor(new Proveedores(cifProveedor), funcionalidad.obtenerId(nombreUsuario));
                if (proveedorExistente != null) {
                    //Modificamos la disponibilidad del proveedor a 0
                    if(proveedorExistente.getDisponible()==1){
                        long resultado = funcionalidad.modificarDisponibilidadProveedor(proveedorExistente, 0);
                        if (resultado == -1) {
                            Toast.makeText(getActivity(), "Error al modificar la disponibilidad del proveedor", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Toast.makeText(getActivity(), "Proveedor eliminado", Toast.LENGTH_SHORT).show();
                        actvCifProveedor.setText("");
                        Intent intent=new Intent(getActivity(), Toolbar.class);
                        startActivity(intent);
                    }else{
                        Toast.makeText(getActivity(), "Proveedor no disponible", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getActivity(), "El proveedor no existe", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });


        return view;
    }

}