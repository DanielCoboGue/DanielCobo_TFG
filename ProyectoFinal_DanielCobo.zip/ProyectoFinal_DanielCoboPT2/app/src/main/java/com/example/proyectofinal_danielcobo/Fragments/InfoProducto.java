package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.util.Locale;

public class InfoProducto extends AppCompatActivity {

    TextView textNombreProducto, textCifProveedor, textCantidadProducto, textPrecioCompra, textCategoria;
    Funcionalidad funcionalidad;
    ConexionBD conexionBD;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_info_producto);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Inicializamos la base de datos
        conexionBD = new ConexionBD(InfoProducto.this);
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());
        SharedPreferences preferences = getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = preferences.getString("usuario", null);
        int idUsuario = funcionalidad.obtenerId(nombreUsuario);

        //Inicializamos los campos
        textNombreProducto = findViewById(R.id.textNombreProducto);
        textCifProveedor = findViewById(R.id.textCifProveedor);
        textCantidadProducto = findViewById(R.id.textCantidadProducto);
        textPrecioCompra = findViewById(R.id.textPrecioCompra);
        textCategoria = findViewById(R.id.textCategoriaProducto);

        //Obtenemos los datos del intent
        String nombreProducto = getIntent().getStringExtra("nombreProducto");
        String cifProveedor = getIntent().getStringExtra("cifProveedor");
        int cantidad = getIntent().getIntExtra("cantidad", 0);
        String categoria = getIntent().getStringExtra("categoria");

        //Mostramos los datos en los campos
        textNombreProducto.setText(nombreProducto);
        textCifProveedor.setText("CIF: " + cifProveedor);
        textCantidadProducto.setText("Cantidad: " + cantidad);
        //Formato de dos decimales

        textPrecioCompra.setText("Precio: " + String.format(Locale.getDefault(), "%.2f", funcionalidad.obtenerPrecioCompra(nombreProducto, cifProveedor, idUsuario)) + "€");
        textCategoria.setText("Categoría: " + categoria);

    }
}