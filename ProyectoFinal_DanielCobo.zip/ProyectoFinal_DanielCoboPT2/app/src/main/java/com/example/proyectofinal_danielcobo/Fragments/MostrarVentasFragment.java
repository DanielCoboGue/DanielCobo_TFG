package com.example.proyectofinal_danielcobo.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Adaptadores.AdaptadorVentas;
import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo2.R;

import java.util.ArrayList;
import java.util.Locale;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MostrarVentasFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MostrarVentasFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    Funcionalidad funcionalidad;
    ConexionBD conexionBD;
    ListView listaVentas;
    ArrayList<Ventas> ventas=new ArrayList<>();
    TextView tvGananciasTotales;
    TextView tvVentasTotales;
    TextView tvProductosVendidos;
    TextView tvNumeroVentas;
    TextView tvImpuestos;

    public MostrarVentasFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MostrarVentasFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MostrarVentasFragment newInstance(String param1, String param2) {
        MostrarVentasFragment fragment = new MostrarVentasFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Infla el layout del fragment
        View view = inflater.inflate(R.layout.fragment_mostrar_ventas, container, false);
        //Inicializamos la base de datos
        conexionBD = new ConexionBD(getActivity());
        funcionalidad = new Funcionalidad(conexionBD.getWritableDatabase());

        //Codigo que nos impide volver con el boton de atras
        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );
        //Obtenemos el nombre del usuario de las preferencias
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("sesion", Context.MODE_PRIVATE);
        String nombreUsuario = sharedPreferences.getString("usuario", null);
        int idUsuario = funcionalidad.obtenerId(nombreUsuario);

        //Inicializamos las variables
        tvGananciasTotales = view.findViewById(R.id.tvGananciasTotales);
        tvVentasTotales = view.findViewById(R.id.tvVentasTotales);
        tvProductosVendidos = view.findViewById(R.id.tvProductosVendidos);
        tvNumeroVentas = view.findViewById(R.id.tvNumeroVentas);
        tvImpuestos = view.findViewById(R.id.tvImpuestos);

        //Obtenemos las ventas del usuario
        ventas = funcionalidad.getVentas(idUsuario);

        //Creamos las variables para los calculos
        double ventasTotales = 0.0;
        double impuestosTotales = 0.0;
        double ganancias = 0.0;

        //buscamos las ventas una a una
        for (Ventas v : ventas) {
            //Obtenemos el producto y calculamos los precios
            Productos producto = funcionalidad.obtenerProducto(v.getIdProducto());
            double precioVenta = v.getPrecio()*v.getCantidad();
            double precioCompra = funcionalidad.obtenerPrecioCompra(producto.getNombreProducto(), producto.getCifProveedor(), idUsuario)*v.getCantidad();
            String tipoProducto = producto.getCategoria();

            //Calculamos el IVA y el precio
            double tipoIVA = obtenerIVA(tipoProducto);
            //Calculamos el precio de venta
            double baseImponible = precioVenta / (1 + tipoIVA);
            //Calculamos el IVA
            double ivaVenta = precioVenta - baseImponible;
            //Calculamos las ganancias, las ventas totales y los impuestos
            ventasTotales += precioVenta;
            impuestosTotales += ivaVenta;
            ganancias += (baseImponible - precioCompra);
        }

        //Mostramos los resultados
        tvVentasTotales.setText(getString(R.string.ventasTotales) + String.format(Locale.getDefault(), "%.2f", ventasTotales) + " €");
        tvImpuestos.setText(getString(R.string.impuestos) + String.format(Locale.getDefault(), "%.2f", impuestosTotales) + " €");
        tvGananciasTotales.setText(getString(R.string.gananciasTotales) + String.format(Locale.getDefault(), "%.2f", ganancias) + " €");
        tvProductosVendidos.setText(getString(R.string.productosVendidos) + funcionalidad.productosVendidos(idUsuario));
        tvNumeroVentas.setText(getString(R.string.numeroVentas) + funcionalidad.numeroVentas(idUsuario));

        //Instanciamos el listView y cargamos ventas
        listaVentas = view.findViewById(R.id.listadoVentas);
        listaVentas.setAdapter(new AdaptadorVentas(getActivity(), ventas));

        return view;
    }

    //Calcula el IVA según la categoría del producto
    private double obtenerIVA(String tipoProducto) {
        switch (tipoProducto) {
            case "Exento":
                return 0.0;
            case "Tipo Reducido":
                return 0.04;
            case "Tipo Intermedio":
                return 0.10;
            case "Tipo Especial":
                return 0.30;
            default:
                return 0.21;
        }
    }
}