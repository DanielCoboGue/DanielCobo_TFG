package com.example.proyectofinal_danielcobo.Fragments;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;

import androidx.activity.OnBackPressedCallback;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;
import com.example.proyectofinal_danielcobo.Principales.ConexionBD;
import com.example.proyectofinal_danielcobo.Principales.Funcionalidad;
import com.example.proyectofinal_danielcobo.Principales.Toolbar;
import com.example.proyectofinal_danielcobo2.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class VentaProductoFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private EditText editTextPrecio;
    private EditText editTextCantidad;
    private EditText editTextDescripcion;
    private Button buttonRealizarVenta;
    ConexionBD conexion;
    Funcionalidad funcionalidad;
    PendingIntent pend;
    Toolbar toolbar;
    public String nombreProducto;
    public String cantidad;
    public String nombreUsuario;
    private static final String CHANNEL_ID = "notificacion";
    private static final int NOTIFICATION_ID = 0;
    AutoCompleteTextView actvProductos;
    ArrayList<Productos> listaProductos;

    public VentaProductoFragment() { }

    public static VentaProductoFragment newInstance(String param1, String param2) {
        VentaProductoFragment fragment = new VentaProductoFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        conexion = new ConexionBD(getContext());
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_venta_producto, container, false);

        requireActivity().getOnBackPressedDispatcher().addCallback(
                getViewLifecycleOwner(),
                new OnBackPressedCallback(true) {
                    @Override
                    public void handleOnBackPressed() {
                        Toast.makeText(getActivity(), "No puedes volver atrás mediante este botón", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        SharedPreferences preferencesSesion = getActivity().getSharedPreferences("sesion", getActivity().MODE_PRIVATE);
        nombreUsuario = preferencesSesion.getString("usuario", null);
        String contrasenia = preferencesSesion.getString("contrasenia", null);

        actvProductos = view.findViewById(R.id.spinnerProductosVenta);

        try {
            listaProductos = funcionalidad.getProductosPorUsuario(funcionalidad.obtenerId(nombreUsuario));
            ArrayList<String> nombresProductos = new ArrayList<>();
            for (Productos p : listaProductos) {
                nombresProductos.add(p.getNombreProducto() + " (" + funcionalidad.obtenerNombreProveedor(p.getCifProveedor()) +" -> "+ p.getCifProveedor()+")");
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, nombresProductos);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            actvProductos.setAdapter(adapter);
            actvProductos.setThreshold(1);
        } catch (IllegalArgumentException e) {
            Toast.makeText(getActivity(), "No hay productos", Toast.LENGTH_SHORT).show();
        }

        editTextPrecio = view.findViewById(R.id.etextPrecioVenta);
        editTextCantidad = view.findViewById(R.id.etextCantidadVenta);
        editTextDescripcion = view.findViewById(R.id.etextDescripcionVenta);
        buttonRealizarVenta = view.findViewById(R.id.btnRealizarVenta);

        buttonRealizarVenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Usuarios usuario = funcionalidad.buscarUsuario(new Usuarios(nombreUsuario, contrasenia, funcionalidad.obtenerNotificacionesUsuario(nombreUsuario), funcionalidad.obtenerProvincia(nombreUsuario)));
                if (usuario == null) {
                    Toast.makeText(getActivity(), "Usuario no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                int usuarioId = usuario.getId();

                //Obtenemos el producto
                Productos producto;
                String cifProveedor=null;
                try {
                    nombreProducto=actvProductos.getText().toString().split("\\(")[0];
                    cifProveedor = actvProductos.getText().toString().split("-> ")[1].replace(")", "").trim();
                }catch (ArrayIndexOutOfBoundsException e){
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    return;
                }

                try{
                    producto = funcionalidad.obtenerProductoPorProveedor(nombreProducto, cifProveedor, usuarioId);
                }catch (IndexOutOfBoundsException e){
                    Toast.makeText(getActivity(), "No se ha seleccionado un producto", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (producto == null) {
                    Toast.makeText(getActivity(), "Producto no encontrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos el producto
                int idProducto = producto.getIdProducto();
                String precio = editTextPrecio.getText().toString();
                cantidad = editTextCantidad.getText().toString();
                String descripcion = editTextDescripcion.getText().toString();

                if (nombreProducto.isEmpty() || precio.isEmpty() || cantidad.isEmpty() || descripcion.isEmpty()) {
                    Toast.makeText(getActivity(), "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Obtenemos la fecha y hora actual
                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String fechaHora = dateFormat.format(calendar.getTime());

                //Creamos la venta
                Ventas venta = new Ventas(usuarioId, idProducto, Double.parseDouble(precio), Integer.parseInt(cantidad), fechaHora, descripcion);
                //Obtenemos la nueva cantidad del producto
                int nuevaCantidad = producto.getCantidadProducto() - Integer.parseInt(cantidad);
                if (Integer.parseInt(cantidad) <= 0 || Double.parseDouble(precio) <= 0.0){
                    Toast.makeText(getActivity(), "La cantidad y el precio no pueden ser 0", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos que la cantidad sea positiva
                if (nuevaCantidad < 0) {
                    Toast.makeText(getActivity(), "La cantidad resultante de la venta no puede ser negativa", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    //Creamos la venta
                    long id = funcionalidad.crearVenta(venta, usuarioId);
                    //Comprobamos que se haya realizado la venta
                    if (id != -1) {
                        Toast.makeText(getActivity(), "Venta realizada con éxito", Toast.LENGTH_SHORT).show();
                        funcionalidad.modificarCantidadProductoPorProveedor(producto,nuevaCantidad);
                        Toast.makeText(getActivity(), "Producto modificado con éxito", Toast.LENGTH_SHORT).show();

                        //Creamos la notificacion segun el stock
                        setPendingItem();
                        crearNotificacion();
                        if (nuevaCantidad == 0) {
                            lanzarNotificacionVenta("El producto " + nombreProducto + " se ha quedado sin stock.");
                        } else if (nuevaCantidad <= 2) {
                            lanzarNotificacionVenta("Stock bajo: el producto " + nombreProducto + " tiene solo " + nuevaCantidad + " unidades.");
                        }

                        limpiarCampos();
                        Intent intent = new Intent(getActivity(), Toolbar.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getActivity(), "Error al realizar la venta", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });

        return view;
    }

    private void limpiarCampos() {
        actvProductos.setText("");
        editTextPrecio.setText("");
        editTextCantidad.setText("");
        editTextDescripcion.setText("");
    }

    private void setPendingItem() {
        Intent intent = new Intent(getActivity(), Toolbar.class);
        pend = PendingIntent.getActivity(getActivity(), 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    public void crearNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notificacion";
            String description = "Exito";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel canal = new NotificationChannel(CHANNEL_ID, name, importance);
            canal.setDescription(description);
            canal.enableLights(true);
            canal.setLightColor(Color.BLUE);

            NotificationManager manager = (NotificationManager) getActivity().getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(canal);
            }
        }
    }

    public void lanzarNotificacionVenta(String mensaje) {
        NotificationCompat.Builder constructor = new NotificationCompat.Builder(getActivity(), CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentTitle("Notificación de Stock")
                .setContentText(mensaje)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pend)
                .setAutoCancel(true);

        NotificationManagerCompat noti = NotificationManagerCompat.from(getActivity());
        if (ActivityCompat.checkSelfPermission(getActivity(), android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                && funcionalidad.obtenerNotificacionesUsuario(nombreUsuario)) {
            noti.notify(NOTIFICATION_ID, constructor.build());
        }
    }
}
