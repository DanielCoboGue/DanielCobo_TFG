package com.example.proyectofinal_danielcobo.Pojo;

public class Pedidos {
    // Atributos de la clase
    private int id;
    private int usuarioId;
    private int idProducto;
    private String descripcion;
    private int cantidad;
    private String fechaHora;

    // Constructor con todos los parámetros
    public Pedidos(int id, int usuarioId, int idProducto, int cantidad, String fechaHora, String descripcion) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.idProducto = idProducto;
        this.cantidad=cantidad;
        this.descripcion = descripcion;
        this.fechaHora = fechaHora;
    }
    // Constructor con todos los parámetros menos id
    public Pedidos(int usuarioId, int idProducto, int cantidad, String fechaHora, String descripcion) {
        this.usuarioId = usuarioId;
        this.descripcion = descripcion;
        this.idProducto=idProducto;
        this.cantidad=cantidad;
        this.fechaHora = fechaHora;
    }

    //Metodos get y set de los atributos
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public int getIdProducto(){
        return idProducto;
    }
    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }
    public int getCantidad(){
        return cantidad;
    }
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    public String getFechaHora() {
        return fechaHora;
    }
    public void setFechaHora(String fechaHora) {
        this.fechaHora = fechaHora;
    }

}
