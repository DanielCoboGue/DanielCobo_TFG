package com.example.proyectofinal_danielcobo.Pojo;

public class Productos {
    //Atributos de la clase
    private int id;
    private String cifProveedor;
    private String nombreProducto;
    private int cantidad;
    private int disponible;
    private double precioCompra;
    private String categoria;
    private int usuarioId;

    //Constructor
    public Productos(int id, String cifProveedor,String nombreProducto, int cantidad, int disponible, double precioCompra, String categoria, int usuarioId) {
        this.id = id;
        this.cifProveedor = cifProveedor;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.disponible = disponible;
        this.precioCompra = precioCompra;
        this.categoria = categoria;
        this.usuarioId = usuarioId;
    }
    //Constructor
    public Productos(String cifProveedor, String nombreProducto, int cantidad, int disponible, double precioCompra, String categoria, int usuarioId) {
        this.cifProveedor = cifProveedor;
        this.nombreProducto = nombreProducto;
        this.cantidad = cantidad;
        this.disponible = disponible;
        this.precioCompra = precioCompra;
        this.categoria = categoria;
        this.usuarioId = usuarioId;
    }
    //Metodos get y set de los atributos
    public int getUsuarioId() {
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
    }

    public int getIdProducto() {
        return id;
    }
    public void setIdProducto(int id) {
        this.id = id;
    }
    public String getCifProveedor(){
        return cifProveedor;
    }
    public void setCifProveedor(String cifProveedor){
        this.cifProveedor=cifProveedor;
    }
    public String getNombreProducto(){
        return nombreProducto;
    }
    public void setNombreProducto(String nombreProducto){
        this.nombreProducto=nombreProducto;
    }
    public int getCantidadProducto(){
        return cantidad;
    }
    public void setCantidadProducto(int cantidad) {
        this.cantidad = cantidad;
    }
    public int getDisponible() {
        return disponible;
    }
    public void setDisponible(int disponible) {
        this.disponible = disponible;
    }
    public double getPrecioCompra() {
        return precioCompra;
    }
    public void setPrecioCompra(double precioCompra) {
        this.precioCompra = precioCompra;
    }
    public String getCategoria() {
        return categoria;
    }
    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
}
