package com.example.proyectofinal_danielcobo.Pojo;

public class Proveedores {
    //Atributos de la clase
    private String cifProveedor;
    private String nombreProveedor;
    private String provincia;
    private int usuarioId;
    private int disponible;

    //Constructor
    public Proveedores(String cifProveedor) {
        this.cifProveedor = cifProveedor;
    }
    //Constructor
    public Proveedores(String cifProveedor, String nombreProveedor, String provincia, int usuarioId, int disponible) {
        this.cifProveedor = cifProveedor;
        this.nombreProveedor = nombreProveedor;
        this.provincia = provincia;
        this.usuarioId = usuarioId;
        this.disponible = disponible;
    }

    //Metodos get y set de los atributos
    public String getCifProveedor(){
        return cifProveedor;
    }
    public void setCifProveedor(String cifProveedor){
        this.cifProveedor=cifProveedor;
    }
    public String getNombreProveedor(){
        return nombreProveedor;
    }
    public void setNombreProveedor(String nombreProveedor){
        this.nombreProveedor=nombreProveedor;
    }
    public String getProvincia(){
        return provincia;
    }
    public void setProvincia(String provincia){
        this.provincia=provincia;
    }
    public int getUsuarioId(){
        return usuarioId;
    }
    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }
    public int getDisponible() {
        return disponible;
    }
    public void setDisponible(int disponible) {
        this.disponible = disponible;
    }
}
