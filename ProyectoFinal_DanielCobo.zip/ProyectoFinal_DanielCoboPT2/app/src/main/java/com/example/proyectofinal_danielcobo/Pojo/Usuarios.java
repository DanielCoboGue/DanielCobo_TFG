package com.example.proyectofinal_danielcobo.Pojo;

public class Usuarios {
    //Atributos de la clase
    private int id;
    private String nombreUsuario;
    private String contrasenia;
    private boolean notificaciones;
    private String provincia;

    //Constructor
    public Usuarios(int id, String nombreUsuario, String contrasenia, boolean notificaciones, String provincia){
        this.id=id;
        this.nombreUsuario=nombreUsuario;
        this.contrasenia=contrasenia;
        this.notificaciones=notificaciones;
        this.provincia=provincia;
    }
    //Constructor
    public Usuarios(String nombreUsuario, String contrasenia, boolean notificaciones, String provincia){
        this.nombreUsuario=nombreUsuario;
        this.contrasenia=contrasenia;
        this.notificaciones=notificaciones;
        this.provincia=provincia;

    }

    //Metodos get y set de los atributos
    public int getId(){
        return id;
    }

    public String getNombreUsuario(){
        return nombreUsuario;
    }
    public void setNombreUsuario(String nombreUsuario){
        this.nombreUsuario=nombreUsuario;
    }

    public String getContrasenia(){
        return contrasenia;
    }
    public void setContrasenia(String contrasenia){
        this.contrasenia=contrasenia;
    }
    public boolean getNotificaciones(){
        return notificaciones;
    }
    public void setNotificaciones(boolean notificaciones){
        this.notificaciones=notificaciones;
    }
    public String getProvincia(){
        return provincia;
    }
    public void setProvincia(String provincia){
        this.provincia=provincia;
    }

}
