package com.example.proyectofinal_danielcobo.Principales;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ConexionBD extends SQLiteOpenHelper {

    //Nombre de la base de datos
    private static final String DATABASE_NAME = "proyecto.db";
    private static final int DATABASE_VERSION = 5;
    //Creamos las tablas
    private static final String CREATE_USUARIOS = "CREATE TABLE usuarios(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "nombreUsuario TEXT NOT NULL UNIQUE," +
            "contrasenia TEXT NOT NULL," +
            "notificaciones BOOLEAN DEFAULT 'false'," +
            "provincia TEXT NOT NULL DEFAULT 'Valladolid')";
    private static final String CREATE_PROVEEDORES = "CREATE TABLE proveedores(" +
            "cifProveedor TEXT ," +
            "nombreProveedor TEXT NOT NULL," +
            "provincia TEXT NOT NULL DEFAULT 'Valladolid'," +
            "usuarioId INTEGER NOT NULL," +
            "disponible INTEGER NOT NULL DEFAULT 1,"+
            "FOREIGN KEY (usuarioId) REFERENCES usuarios(id)," +
            "UNIQUE (cifProveedor, usuarioId, nombreProveedor)," +
            "PRIMARY KEY(cifProveedor,usuarioId))";
    private static final String CREATE_PRODUCTOS = "CREATE TABLE productos(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "cifProveedor TEXT NOT NULL," +
            "nombreProducto TEXT NOT NULL," +
            "cantidad INTEGER NOT NULL," +
            "disponible INTEGER NOT NULL DEFAULT 1,"+
            "precioCompra REAL NOT NULL," +
            "categoria TEXT NOT NULL," +
            "usuarioId INTEGER NOT NULL," +
            "FOREIGN KEY (cifProveedor) REFERENCES proveedores(cifProveedor)," +
            "CHECK (cantidad >= 0)," +
            "UNIQUE (cifProveedor, nombreProducto, usuarioId))";
    private static final String CREATE_PEDIDOS = "CREATE TABLE pedidos(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "usuarioId INTEGER NOT NULL," +
            "idProducto INTEGER NOT NULL," +
            "cantidad INTEGER NOT NULL," +
            "fechaHora TEXT NOT NULL," +
            "descripcion TEXT NOT NULL," +
            "FOREIGN KEY (usuarioId) REFERENCES usuarios(id)," +
            "FOREIGN KEY (idProducto) REFERENCES productos(id)," +
            "CHECK (cantidad >0)," +
            "UNIQUE (id, usuarioId, idProducto))";
    private static final String CREATE_VENTAS = "CREATE TABLE ventas(" +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "usuarioId INTEGER NOT NULL," +
            "idProducto INTEGER NOT NULL," +
            "precio REAL NOT NULL," +
            "cantidad INTEGER NOT NULL,"+
            "fechaHora TEXT NOT NULL," +
            "descripcion TEXT NOT NULL," +
            "FOREIGN KEY (usuarioId) REFERENCES usuarios(id)," +
            "FOREIGN KEY (idProducto) REFERENCES productos(id)," +
            "CHECK (cantidad > 0)," +
            "UNIQUE (id, usuarioId, idProducto)" +
            ")";
//Constructor
    public ConexionBD(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    //Metodos de la clase
    //Metodo que crea las tablas
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USUARIOS);
        db.execSQL(CREATE_PROVEEDORES);
        db.execSQL(CREATE_PRODUCTOS);
        db.execSQL(CREATE_PEDIDOS);
        db.execSQL(CREATE_VENTAS);
    }
    //Metodo que actualiza las tablas
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS ventas");
        db.execSQL("DROP TABLE IF EXISTS pedidos");
        db.execSQL("DROP TABLE IF EXISTS productos");
        db.execSQL("DROP TABLE IF EXISTS proveedores");
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }

}
