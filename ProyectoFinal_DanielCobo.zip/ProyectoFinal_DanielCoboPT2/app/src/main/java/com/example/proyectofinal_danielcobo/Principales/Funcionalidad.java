package com.example.proyectofinal_danielcobo.Principales;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.proyectofinal_danielcobo.Pojo.Pedidos;
import com.example.proyectofinal_danielcobo.Pojo.Productos;
import com.example.proyectofinal_danielcobo.Pojo.Proveedores;
import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo.Pojo.Ventas;

import java.io.IOException;
import java.util.ArrayList;

public class Funcionalidad {
    //Creamos la variable de la clase
    private static SQLiteDatabase conexion;
    //Constructor
    public Funcionalidad(SQLiteDatabase conexion){
        this.conexion=conexion;
    }
    //Metodos de la clase
    //Metodo para insertar un usuario
    public long insertar(Usuarios usuario)throws IOException {
        //Creamos un content values para insertar los datos
        //Y lo insertamos en la tabla usuarios
        ContentValues valores=new ContentValues();
        valores.put("nombreUsuario", usuario.getNombreUsuario().toString());
        valores.put("contrasenia", usuario.getContrasenia().toString());

        return conexion.insert("usuarios", null, valores);
    }
    //Metodo para modificar un usuario
    public long modificar(Usuarios usuario, String nombreUsuarioAntiguo){
        ContentValues valores = new ContentValues();
        valores.put("nombreUsuario", usuario.getNombreUsuario());
        valores.put("contrasenia", usuario.getContrasenia());

        return conexion.update("usuarios", valores, "nombreUsuario = ?", new String[]{nombreUsuarioAntiguo});
    }
    //Metodo para obtener el id del usuario
    public int obtenerId(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"id"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        int id = 0;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            cursor.close();
            return id;
        }
        cursor.close();
        return id;
    }
    //Metodo para insertar en la tabla notificaciones
    public long modificarNotificaciones(Usuarios usuario, boolean notificaciones) {
        ContentValues values = new ContentValues();
        if (notificaciones) {
            values.put("notificaciones", "true");
        } else {
            values.put("notificaciones", "false");
        }

        return conexion.update("usuarios", values, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()});
    }
    //Metodo para obtener si las notificaciones estan activadas op no
    public boolean obtenerNotificacionesUsuario(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"notificaciones"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        boolean notificaciones = false;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            String notificacionesUsuario = cursor.getString(cursor.getColumnIndexOrThrow("notificaciones"));
            if (notificacionesUsuario.equals("true")) {
                notificaciones = true;
            }
            cursor.close();
            return notificaciones;
        }
        cursor.close();
        return notificaciones;
    }
    //Obtener usuario por nombre de usuario
    public Usuarios obtenerUsuarioPorNombre(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"*"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        Usuarios usuario = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombreUsuario"));
            String contrasenia = cursor.getString(cursor.getColumnIndexOrThrow("contrasenia"));
            boolean notificaciones = cursor.getInt(cursor.getColumnIndexOrThrow("notificaciones")) == 1;
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            cursor.close();
            return new Usuarios(id, nombre, contrasenia, notificaciones, provincia);
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para obtener la provincia
    public String obtenerProvincia(String nombreUsuario){
        Cursor cursor = conexion.query("usuarios", new String[]{"provincia"}, "nombreUsuario = ?", new String[]{nombreUsuario},
                null, null, null
        );
        String provincia = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            cursor.close();
        }
        return provincia;
    }
    //Metodo para buscar un usuario
    public Usuarios buscarUsuario(Usuarios usuario) {
        Cursor cursor = conexion.rawQuery("SELECT id, nombreUsuario, contrasenia FROM usuarios WHERE nombreUsuario = ? AND contrasenia = ?",
                new String[]{usuario.getNombreUsuario(), usuario.getContrasenia()});

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(0);
            String nombreUsuario = cursor.getString(1);
            String contrasenia = cursor.getString(2);
            cursor.close();
            return new Usuarios(id, nombreUsuario, contrasenia, obtenerNotificacionesUsuario(nombreUsuario), obtenerProvincia(nombreUsuario));
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para modificar la provincia
    public long modificarProvincia(Usuarios usuario, String provincia){
        ContentValues valores = new ContentValues();
        valores.put("provincia", provincia);
        return conexion.update("usuarios", valores, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()});
    }
    //Metodo para obtener el id de un usuario
    public String obtenerNombreUsuario(Usuarios usuario){
        //Creo la variable donde guardo los resultados
        Cursor cursor = conexion.query("usuarios", new String[]{"nombreUsuario"}, "nombreUsuario = ?", new String[]{usuario.getNombreUsuario()},
                null, null, null
        );
        String nombreUsuario = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreUsuario = cursor.getString(cursor.getColumnIndexOrThrow("nombreUsuario"));
            cursor.close();
        }
        return nombreUsuario;
    }
    //Metodo para insertar un pedido
    public long insertarPedido(Pedidos pedido, int usuarioIdActual){
        ContentValues valores=new ContentValues();
        valores.put("usuarioId", usuarioIdActual);
        valores.put("idProducto", pedido.getIdProducto());
        valores.put("cantidad", pedido.getCantidad());
        valores.put("descripcion", pedido.getDescripcion());
        valores.put("fechaHora", pedido.getFechaHora());

        return conexion.insert("pedidos", null, valores);
    }
    //Metodo para obtener los pedidos de un usuario
    public ArrayList<Pedidos> getPedidos(int usuarioId) {
        ArrayList<Pedidos> listaPedidos = new ArrayList<>();
        Cursor cursor = conexion.query("pedidos", null, "usuarioId = ?", new String[]{String.valueOf(usuarioId)}, null, null, "fechaHora DESC");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int idProducto = cursor.getInt(cursor.getColumnIndexOrThrow("idProducto"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            String fechaHora = cursor.getString(cursor.getColumnIndexOrThrow("fechaHora"));
            String descripcion = cursor.getString(cursor.getColumnIndexOrThrow("descripcion"));
            Pedidos pedido = new Pedidos(id, idUsuario, idProducto, cantidad, fechaHora, descripcion);
            listaPedidos.add(pedido);
        }
        cursor.close();
        return listaPedidos;
    }
    //Metodo para modificar la cantidad de un producto de proveedor por usuario
    public long modificarCantidadProductoPorProveedor(Productos producto, int nuevaCantidad){
        ContentValues valores = new ContentValues();
        valores.put("cantidad", nuevaCantidad);
        return conexion.update("productos", valores, "cifProveedor = ? AND nombreProducto = ? AND usuarioId = ?", new String[]{producto.getCifProveedor(), producto.getNombreProducto(), String.valueOf(producto.getUsuarioId())});
    }
    //Metodo para crear una venta
    public long crearVenta(Ventas venta, int usuarioIdActual){
        ContentValues valores=new ContentValues();
        valores.put("usuarioId", usuarioIdActual);
        valores.put("idProducto", venta.getIdProducto());
        valores.put("precio", venta.getPrecio());
        valores.put("cantidad", venta.getCantidad());
        valores.put("fechaHora", venta.getFechaHora());
        valores.put("descripcion", venta.getDescripcion());
        return conexion.insert("ventas", null, valores);
    }
    //Buscamos un proveedor
    public Proveedores buscarProveedor(Proveedores proveedor, int usuarioId) {
        Cursor cursor = conexion.rawQuery("SELECT * FROM proveedores WHERE cifProveedor = ? AND disponible = 1 AND usuarioId = ?", new String[]{proveedor.getCifProveedor(), String.valueOf(usuarioId)});
        if (cursor.moveToFirst()) {
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            cursor.close();
            return new Proveedores(cifProveedor, nombreProveedor, provincia, idUsuario, disponible);
        } else {
            cursor.close();
            return null;
        }
    }
    //Buscamos proveedor general
    public Proveedores buscarProveedorGeneral(Proveedores proveedor) {
        Cursor cursor = conexion.rawQuery("SELECT * FROM proveedores WHERE cifProveedor = ? AND nombreProveedor = ? AND provincia = ? AND usuarioId = ? AND disponible = ?",
                new String[]{proveedor.getCifProveedor(), proveedor.getNombreProveedor(), proveedor.getProvincia(), String.valueOf(proveedor.getUsuarioId()), String.valueOf(proveedor.getDisponible())});
        if (cursor.moveToFirst()) {
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            cursor.close();
            return new Proveedores(cifProveedor, nombreProveedor, provincia, idUsuario, disponible);
        } else {
            cursor.close();
            return null;
        }
    }
    //Buscar proveedor por Cif
    public Proveedores buscarProveedorPorCif(String cifProveedor, int usuarioId) {
        Cursor cursor = conexion.rawQuery("SELECT * FROM proveedores WHERE cifProveedor = ? AND usuarioId = ?", new String[]{cifProveedor, String.valueOf(usuarioId)});
        if (cursor.moveToFirst()) {
            String cifProveedorEncontrado = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            cursor.close();
            return new Proveedores(cifProveedorEncontrado, nombreProveedor, provincia, idUsuario, disponible);
        } else {
            cursor.close();
            return null;
        }
    }
    //Metodo para insertar proveedor
    public long insertarProveedor(Proveedores proveedor)throws IOException {
        ContentValues valores=new ContentValues();
        valores.put("cifProveedor", proveedor.getCifProveedor());
        valores.put("nombreProveedor", proveedor.getNombreProveedor());
        valores.put("provincia", proveedor.getProvincia());
        valores.put("usuarioId", proveedor.getUsuarioId());
        return conexion.insert("proveedores", null, valores);
    }
    //Metodo para obtener los proveedores de un usuario en un arraylist
    public ArrayList<Proveedores> getProveedores(int usuarioId) {
        ArrayList<Proveedores> listaProveedores = new ArrayList<>();
        Cursor cursor = conexion.query("proveedores", null, "usuarioId = ? AND disponible = 1", new String[]{String.valueOf(usuarioId)}, null, null, null);
        while (cursor.moveToNext()) {
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            String nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            String provincia = cursor.getString(cursor.getColumnIndexOrThrow("provincia"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            Proveedores proveedor = new Proveedores(cifProveedor, nombreProveedor, provincia, idUsuario, disponible);
            listaProveedores.add(proveedor);
        }
        cursor.close();
        return listaProveedores;
    }
    //Insertamos un produto
    public long insertarProducto(Productos producto, int usuarioIdActual){
        ContentValues valores=new ContentValues();
        valores.put("cifProveedor", producto.getCifProveedor());
        valores.put("nombreProducto", producto.getNombreProducto());
        valores.put("cantidad", producto.getCantidadProducto());
        valores.put("disponible", producto.getDisponible());
        valores.put("precioCompra", producto.getPrecioCompra());
        valores.put("categoria", producto.getCategoria());
        valores.put("usuarioId", usuarioIdActual);
        return conexion.insert("productos", null, valores);
    }
    //Obtenemos el nombre de producto por su id
    public String obtenerNombreProducto(int idProducto){
        Cursor cursor = conexion.query("productos", new String[]{"nombreProducto"}, "id = ?", new String[]{String.valueOf(idProducto)},
                null, null, null
        );
        String nombreProducto = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreProducto = cursor.getString(cursor.getColumnIndexOrThrow("nombreProducto"));
            cursor.close();
        }
        return nombreProducto;
    }
    //Obtenemos los productos de los provedores con nuestro id de usuario
    public ArrayList<Productos> getProductosPorUsuario(int usuarioId) {
        ArrayList<Productos> productos = new ArrayList<>();

        String consulta = "SELECT p.id, p.cifProveedor, p.nombreProducto, p.cantidad, p.disponible, p.precioCompra, p.categoria FROM productos p " +
                "JOIN proveedores pr ON p.cifProveedor = pr.cifProveedor " +
                "WHERE pr.usuarioId = ? AND p.usuarioId = ? AND p.disponible = 1";

        Cursor cursor = conexion.rawQuery(consulta, new String[]{String.valueOf(usuarioId), String.valueOf(usuarioId)});

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
                String nombreProducto = cursor.getString(cursor.getColumnIndexOrThrow("nombreProducto"));
                int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
                int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
                int precioCompra = cursor.getInt(cursor.getColumnIndexOrThrow("precioCompra"));
                String categoria = cursor.getString(cursor.getColumnIndexOrThrow("categoria"));

                productos.add(new Productos(id, cifProveedor, nombreProducto, cantidad, disponible, precioCompra, categoria, usuarioId));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return productos;
    }
    //Metodo para obtener el cif de un proveedor por nombre de producto y id de usuario
    public String obtenerCifProveedor(String nombreProducto, int usuarioId) {
        String cifProveedor = null;
        String consulta = "SELECT p.cifProveedor FROM productos p " +
                "JOIN proveedores pr ON p.cifProveedor = pr.cifProveedor " +
                "WHERE p.nombreProducto = ? AND pr.usuarioId = ?";

        Cursor cursor = conexion.rawQuery(consulta, new String[]{nombreProducto, String.valueOf(usuarioId)});

        if (cursor.moveToFirst()) {
            cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
        }
        cursor.close();
        return cifProveedor;
    }
    //Obtener producto por nombre de producto de un proveedor
    public Productos obtenerProductoPorProveedor(String nombreProducto, String cifProveedor, int usuarioId){
        nombreProducto = nombreProducto.trim();
        cifProveedor = cifProveedor.trim();

        Cursor cursor = conexion.query(
                "productos", new String[]{"*"},
                "TRIM(nombreProducto) = ? AND TRIM(cifProveedor) = ? AND usuarioId = ?",
                new String[]{nombreProducto, cifProveedor, String.valueOf(usuarioId)},
                null, null, null
        );

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            int precioCompra = cursor.getInt(cursor.getColumnIndexOrThrow("precioCompra"));
            String categoria = cursor.getString(cursor.getColumnIndexOrThrow("categoria"));

            cursor.close();
            return new Productos(id, cifProveedor, nombreProducto, cantidad, disponible, precioCompra, categoria, usuarioId);
        } else {
            cursor.close();
            return null;
        }
    }
    //Obtener nombre provedor por cif del proveedor
    public String obtenerNombreProveedor(String cifProveedor){
        Cursor cursor = conexion.query("proveedores", new String[]{"nombreProveedor"}, "cifProveedor = ?", new String[]{cifProveedor},
                null, null, null
        );
        String nombreProveedor = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            nombreProveedor = cursor.getString(cursor.getColumnIndexOrThrow("nombreProveedor"));
            cursor.close();
        }
        return nombreProveedor;
    }
    //Metodo para obtener si un producto esta disponible
    public int obtenerProductoDisponible(int idProducto){
        Cursor cursor = conexion.query("productos", new String[]{"cantidad"}, "id = ?", new String[]{String.valueOf(idProducto)},
                null, null, null
        );
        int disponible = 0;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            disponible = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            cursor.close();
            return 1;
        }
        cursor.close();
        return 0;
    }
    //Metodo para obtener si un proveedor esta disponible
    public int obtenerProveedorDisponible(String cifProveedor){
        Cursor cursor = conexion.query("proveedores", new String[]{"disponible"}, "cifProveedor = ?", new String[]{cifProveedor},
                null, null, null
        );
        int disponible = 0;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            cursor.close();
            return 1;
        }
        cursor.close();
        return 0;
    }
    //Modificamos la disponibilidad de los proveedores
    public long modificarDisponibilidadProveedor(Proveedores proveedor, int nuevaDisponibilidad){
        ContentValues valores = new ContentValues();
        valores.put("disponible", nuevaDisponibilidad);
        return conexion.update("proveedores", valores, "cifProveedor = ? AND usuarioId = ?", new String[]{proveedor.getCifProveedor(), String.valueOf(proveedor.getUsuarioId())});
    }
    //Modificamos la disponibilidad de los productos
    public long modificarDisponibilidadProducto(Productos producto, int nuevaDisponibilidad){
        ContentValues valores = new ContentValues();
        valores.put("disponible", nuevaDisponibilidad);
        return conexion.update("productos", valores, "cifProveedor = ? AND nombreProducto = ? AND usuarioId = ?", new String[]{producto.getCifProveedor(), producto.getNombreProducto(), String.valueOf(producto.getUsuarioId())});
    }
    //Obtenemos las ventas de un usuario
    public ArrayList<Ventas> getVentas(int usuarioId) {
        ArrayList<Ventas> listaVentas = new ArrayList<>();
        Cursor cursor = conexion.query("ventas", null, "usuarioId = ?", new String[]{String.valueOf(usuarioId)}, null, null, "fechaHora DESC");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int idUsuario = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            int idProducto = cursor.getInt(cursor.getColumnIndexOrThrow("idProducto"));
            float precio = cursor.getFloat(cursor.getColumnIndexOrThrow("precio"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            String fechaHora = cursor.getString(cursor.getColumnIndexOrThrow("fechaHora"));
            String descripcion = cursor.getString(cursor.getColumnIndexOrThrow("descripcion"));
            Ventas venta = new Ventas(id, idUsuario, idProducto, precio, cantidad, fechaHora, descripcion);
            listaVentas.add(venta);
        }
        cursor.close();
        return listaVentas;
    }
    //Metodo para obtener las ventas totales de un usuario
    public String ventasTotales(int usuarioId){
        Cursor cursor = conexion.query("ventas", new String[]{"SUM(precio * cantidad)"}, "usuarioId = ?", new String[]{String.valueOf(usuarioId)},
                null, null, null);
        String gananciasTotales = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            gananciasTotales = cursor.getString(cursor.getColumnIndexOrThrow("SUM(precio * cantidad)"));
            cursor.close();
            return gananciasTotales;
        }
        cursor.close();
        return null;
    }
    //Metodo para obtener el numero de ventas de un usuario
    public String numeroVentas(int usuarioId){
        Cursor cursor = conexion.query("ventas", new String[]{"COUNT(*)"}, "usuarioId = ?", new String[]{String.valueOf(usuarioId)},
                null, null, null);
        String numeroVentas = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            numeroVentas = cursor.getString(cursor.getColumnIndexOrThrow("COUNT(*)"));
            cursor.close();
            return numeroVentas;
        }
        cursor.close();
        return null;
    }
    //Metodo para obtener el numero de productos vendidos de un usuario
    public String productosVendidos(int usuarioId){
        Cursor cursor = conexion.query("ventas", new String[]{"COUNT(DISTINCT idProducto)"}, "usuarioId = ?", new String[]{String.valueOf(usuarioId)},
                null, null, null);
        String productosVendidos = null;
        //Compruebo si hay resultados
        if (cursor.moveToFirst()) {
            productosVendidos = cursor.getString(cursor.getColumnIndexOrThrow("COUNT(DISTINCT idProducto)"));
            cursor.close();
            return productosVendidos;
        }
        cursor.close();
        return null;
    }
    //Metodo para modificar el producto
    public long editarProducto(Productos producto, String nombreProductoNuevo, String cifProveedorNuevo, double precioCompraNuevo, String categoriaNuevo){
        ContentValues valores = new ContentValues();
        valores.put("nombreProducto", nombreProductoNuevo);
        valores.put("cifProveedor", cifProveedorNuevo);
        valores.put("precioCompra", precioCompraNuevo);
        valores.put("categoria", categoriaNuevo);

        return conexion.update("productos", valores,"id = ? AND usuarioId = ?", new String[]{String.valueOf(producto.getIdProducto()), String.valueOf(producto.getUsuarioId())});
    }
    //Metodo para comprobar si el proveedor existe en nuestro usuario
    public boolean comprobarProveedorSesion(String cifProveedor, int usuarioId){
        return conexion.query("proveedores", null, "cifProveedor = ? AND usuarioId = ?", new String[]{cifProveedor, String.valueOf(usuarioId)},
                null, null, null).getCount() > 0;
    }
    //Metodo para modificar el proveedor
    public long editarProveedor(Proveedores proveedor, String nombreProveedorNuevo, String provinciaNueva){
        ContentValues valores = new ContentValues();
        valores.put("nombreProveedor", nombreProveedorNuevo);
        valores.put("provincia", provinciaNueva);
        return conexion.update("proveedores", valores, "cifProveedor = ? AND usuarioId = ?", new String[]{ proveedor.getCifProveedor(),String.valueOf(proveedor.getUsuarioId())});
    }
    //Obtenemos el precio de compra por su nombre de producto, cif del proveedor y id de usuario
    public double obtenerPrecioCompra(String nombreProducto, String cifProveedor, int usuarioId){

        Cursor cursor = conexion.query("productos", new String[]{"precioCompra"}, "nombreProducto = ? AND cifProveedor = ? AND usuarioId = ?", new String[]{nombreProducto, cifProveedor, String.valueOf(usuarioId)}, null, null, null);
        if (cursor.moveToFirst()) {
            double precioCompra = cursor.getDouble(cursor.getColumnIndexOrThrow("precioCompra"));
            cursor.close();
            return precioCompra;
        }
        cursor.close();
        return 0.0;
    }
    //Metodo para obtener la categoria de un producto por su nombre, cif del proveedor y id de usuario
    public String obtenerCategoria(String nombreProducto, String cifProveedor, int usuarioId) {
        Cursor cursor = conexion.query("productos", new String[]{"categoria"}, "nombreProducto = ? AND cifProveedor = ? AND usuarioId = ?", new String[]{nombreProducto, cifProveedor, String.valueOf(usuarioId)}, null, null, null);
        if (cursor.moveToFirst()) {
            String categoria = cursor.getString(cursor.getColumnIndexOrThrow("categoria"));
            cursor.close();
            return categoria;
        }
        cursor.close();
        return null;
    }
    //Metodo para obtener un producto en base a su id
    public Productos obtenerProducto(int id){
        Cursor cursor = conexion.query("productos", null, "id = ?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor.moveToFirst()) {
            int idProducto = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int cantidad = cursor.getInt(cursor.getColumnIndexOrThrow("cantidad"));
            String nombreProducto = cursor.getString(cursor.getColumnIndexOrThrow("nombreProducto"));
            String cifProveedor = cursor.getString(cursor.getColumnIndexOrThrow("cifProveedor"));
            int disponible = cursor.getInt(cursor.getColumnIndexOrThrow("disponible"));
            int precioCompra = cursor.getInt(cursor.getColumnIndexOrThrow("precioCompra"));
            String categoria = cursor.getString(cursor.getColumnIndexOrThrow("categoria"));
            int usuarioId = cursor.getInt(cursor.getColumnIndexOrThrow("usuarioId"));
            cursor.close();
            return new Productos(idProducto, cifProveedor, nombreProducto, cantidad, disponible, precioCompra, categoria, usuarioId);
        }
        cursor.close();
        return null;
    }
}


