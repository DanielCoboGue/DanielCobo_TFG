package com.example.proyectofinal_danielcobo.Principales;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectofinal_danielcobo.Pojo.Usuarios;
import com.example.proyectofinal_danielcobo2.R;
import com.google.android.material.textfield.TextInputEditText;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Registro extends AppCompatActivity {
    //Variables de la clase
    Button registrarse;
    TextInputEditText nombreUsuario;
    TextInputEditText contraseniaUsuario;
    TextInputEditText contraseniaRepetirUsuario;
    ConexionBD conexion;
    Funcionalidad funcionalidad;
    TextView linkInicioSesion;
    Animation aparicion;
    ImageView imagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //Instanciamos las variables
        conexion = new ConexionBD(Registro.this);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
        nombreUsuario=findViewById(R.id.tie_nombreUsuarioRegistro);
        contraseniaUsuario=findViewById(R.id.tip_contraseniaRegistro);
        contraseniaRepetirUsuario=findViewById(R.id.tip_repetirContrasenia);
        imagen=findViewById(R.id.imageView);
        //Animamos el logo imagen
        aparicion= AnimationUtils.loadAnimation(this, R.anim.aparicion);
        imagen.startAnimation(aparicion);

        //Cuando un usuario se registre, se insertara en la tabla usuarios
        registrarse=findViewById(R.id.btn_registroSesion);
        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Recogemos los datos introducidos
                String nombre=nombreUsuario.getText().toString().trim();
                String contrasenia=contraseniaUsuario.getText().toString().trim();
                String contraseniaRepetir=contraseniaRepetirUsuario.getText().toString().trim();

                //Comprobamos que los campos no esten vacios
                if(nombre.isEmpty() || contrasenia.isEmpty() || contraseniaRepetir.isEmpty()){
                    Toast.makeText(Registro.this, "Los campos no pueden estar vacios", Toast.LENGTH_SHORT).show();
                    return;
                }
                //Comprobamos que los datos introducidos sean correctos
                if(comprobar(contrasenia, contraseniaRepetir, Registro.this)){
                    //Comprobamos que el usuario no exista por nombre
                    Usuarios usuario=funcionalidad.obtenerUsuarioPorNombre(nombre);
                    if(usuario!=null){
                        Toast.makeText(Registro.this, "El usuario ya existe", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    try {
                        //Encriptamos la contraseña
                        String contraseniaEncriptada=md5(contrasenia);
                        //Insertamos el usuario en la tabla usuarios
                        long resultado=funcionalidad.insertar(new Usuarios(nombre, contraseniaEncriptada, false, "Valladolid"));
                        //Comprobamos el resultado de la insercion
                        if (resultado != -1) {
                            nombreUsuario.setText("");
                            contraseniaUsuario.setText("");
                            contraseniaRepetirUsuario.setText("");
                            Toast.makeText(Registro.this, "Usuario insertado correctamente", Toast.LENGTH_SHORT).show();
                            //Pasamos a la pantalla de inicio de sesion
                            Intent intent=new Intent(Registro.this, MainActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(Registro.this, "Usuario no insertado correctamente", Toast.LENGTH_SHORT).show();
                        }
                    } catch (IOException e) {
                        Toast.makeText(Registro.this, "Error al insertar el usuario", Toast.LENGTH_SHORT).show();
                    }
                }else{
                    Toast.makeText(Registro.this, "Los datos introducidos no son correctos", Toast.LENGTH_SHORT).show();
                }
            }
        });
        //Damos utilidad al boton de ir a inicio de sesion
        linkInicioSesion=findViewById(R.id.linkInicioSesion);
        linkInicioSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Registro.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
    public static String md5(String sInput)  {

        try {
            //obtenemos una instancia de MessageDigest con el algoritmo MD5
            MessageDigest oMd = MessageDigest.getInstance("MD5");

            //convertimos la cadena de entrada a un arreglo de bytes
            byte[] inputBytes = sInput.getBytes();

            //actualizamos el MessageDigest con los bytes de laava cadena
            oMd.update(inputBytes);

            //calculamos el hash MD5
            byte[] aMd5Bytes = oMd.digest();

            //convertimos el hash a una representación hexadecimal
            StringBuilder oSb = new StringBuilder();

            for (byte b : aMd5Bytes) {
                oSb.append(String.format("%02x", b));
            }

            //imprimimos el hash MD5 en formato hexadecimal
            return oSb.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }
    }
    //metodo para comprobar los datos introducidos
    public static boolean comprobar(String contraseniaComprobacion, String contrseniaRepetirComprobacion, Context context){
        //Comprobamos que los datos introducidos sean correctos
        boolean numero=false;
        boolean letra=false;
        boolean tamanio=false;

        if (contraseniaComprobacion.length() <= 12 && contraseniaComprobacion.length() >= 6) {
            tamanio = true;
        }
        for (int i = 0; i < contraseniaComprobacion.length(); i++) {
            if (Character.isDigit(contraseniaComprobacion.charAt(i))) {
                numero = true;
            } else if (Character.isLetter(contraseniaComprobacion.charAt(i))) {
                letra = true;
            }
        }

        if(!tamanio){
            Toast.makeText(context, "El tamaño de la contraseña no es el correcto(6-12 caracteres)", Toast.LENGTH_SHORT).show();
        }else if(!numero){
            Toast.makeText(context, "No hay numeros en la contraseña", Toast.LENGTH_SHORT).show();
        }else if(!letra){
            Toast.makeText(context, "No hay letras en la contraseña", Toast.LENGTH_SHORT).show();
        }

        if(!contraseniaComprobacion.equals(contrseniaRepetirComprobacion)){
            Toast.makeText(context, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (numero && letra && tamanio) {
            return true;
        }

        return false;

    }

}