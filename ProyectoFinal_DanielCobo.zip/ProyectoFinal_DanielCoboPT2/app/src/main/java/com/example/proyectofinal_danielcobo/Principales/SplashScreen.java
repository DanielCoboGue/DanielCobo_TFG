package com.example.proyectofinal_danielcobo.Principales;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.example.proyectofinal_danielcobo2.R;

public class SplashScreen extends AppCompatActivity {
//Creamos las variables de la clase
    ImageView imagen;
    ProgressBar pg;
    int progreso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash_screen);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Instanciamos las variables
        imagen=findViewById(R.id.imageView2);
        pg=findViewById(R.id.progressBar);
        //Animamos la imagen
        Animation rotacion= AnimationUtils.loadAnimation(this, R.anim.rotacion);
        rotacion.setFillAfter(true);
        imagen.startAnimation(rotacion);
        //hilo que controla el progreso de la barra de progreso
        Thread hilo = new Thread(new Runnable() {
            @Override
            public void run() {
                ventana();
                next();
            }
        });

        hilo.start();

    }
    //metodo que controla el progreso de la barra de progreso
    public void ventana(){
        for(progreso=20;progreso<=100;progreso=progreso+20){
            try {
                Thread.sleep(1000);
                pg.setProgress(progreso);
            }catch(InterruptedException e){
                throw new RuntimeException(e);
            }
        }
    }
    //metodo que cambia de ventana
    public void next(){
        Intent nuevaVentana=new Intent(SplashScreen.this, MainActivity.class);
        startActivity(nuevaVentana);
        finish();
    }
}