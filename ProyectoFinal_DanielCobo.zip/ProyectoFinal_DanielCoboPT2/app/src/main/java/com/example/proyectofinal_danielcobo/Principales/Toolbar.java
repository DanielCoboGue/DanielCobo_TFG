package com.example.proyectofinal_danielcobo.Principales;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.example.proyectofinal_danielcobo.Fragments.MasFragment;
import com.example.proyectofinal_danielcobo.Fragments.Configuracion;
import com.example.proyectofinal_danielcobo.Fragments.MostrarVentasFragment;
import com.example.proyectofinal_danielcobo.Fragments.PrincipalFragment;
import com.example.proyectofinal_danielcobo.Fragments.MostrarProductosFragment;
import com.example.proyectofinal_danielcobo.Fragments.MostrarProveedoresFragment;
import com.example.proyectofinal_danielcobo2.R;
import com.example.proyectofinal_danielcobo.Fragments.MenosFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class Toolbar extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    //variables de la clase
    DrawerLayout drawerLayout;
    BottomNavigationView bottomNavigationView;

    public String nombreUsuario;
    ConexionBD conexion;
    Funcionalidad funcionalidad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_toolbar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //Configuramos la toolbar
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Configuramos el drawer y navigation view
        drawerLayout = findViewById(R.id.main);
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //Boton para abrir y cerrar el menu lateral
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout,
                toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();
        //Instanciamos la funcionalidad
        conexion = new ConexionBD(Toolbar.this);
        funcionalidad = new Funcionalidad(conexion.getWritableDatabase());
        bottomNavigationView=findViewById(R.id.botones);
        bottomNavigationView.setSelectedItemId(R.id.boton_pedidos);

        //Cargamos el homefragment por defecto
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new PrincipalFragment()).commit();
        //cambiar el fragment basado en la opcion del menu
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                //Cambiar el fragment basado en la opcion del menu
                Fragment selectedFragment = new PrincipalFragment();
                if(item.getItemId() == R.id.boton_pedidos) {
                    selectedFragment = new PrincipalFragment();
                }else if(item.getItemId() == R.id.boton_mas) {
                    selectedFragment = new MasFragment();
                }else if(item.getItemId() == R.id.boton_menos){
                    selectedFragment = new MenosFragment();
                }

                if(selectedFragment != null){
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
                }

                drawerLayout.closeDrawer(GravityCompat.START);

                return true;
            }
        });

        //Cargamos el homefragment por defecto
        if (savedInstanceState == null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new PrincipalFragment()).commit();
        }

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment selectedFragment = null;

        //Seleccionar el fragment basado en la opcion del menu
        if(item.getItemId() == R.id.nav_proveedores) {
            selectedFragment = new MostrarProveedoresFragment();
            bottomNavigationView.getMenu().setGroupCheckable(0, true, false);
            for (int i = 0; i < bottomNavigationView.getMenu().size(); i++) {
                bottomNavigationView.getMenu().getItem(i).setChecked(false);
            }
            bottomNavigationView.getMenu().setGroupCheckable(0, true, true);
        } else if (item.getItemId() == R.id.nav_productos) {
            selectedFragment = new MostrarProductosFragment();
            bottomNavigationView.getMenu().setGroupCheckable(0, true, false);
            for (int i = 0; i < bottomNavigationView.getMenu().size(); i++) {
                bottomNavigationView.getMenu().getItem(i).setChecked(false);
            }
            bottomNavigationView.getMenu().setGroupCheckable(0, true, true);

        }else if(item.getItemId() == R.id.nav_settings){
            Intent intent = new Intent( Toolbar.this, Configuracion.class);
            startActivity(intent);
            bottomNavigationView.setSelectedItemId(R.id.boton_pedidos);
        }else if (item.getItemId() == R.id.nav_ventas) {
            selectedFragment = new MostrarVentasFragment();
            bottomNavigationView.getMenu().setGroupCheckable(0, true, false);
            for (int i = 0; i < bottomNavigationView.getMenu().size(); i++) {
                bottomNavigationView.getMenu().getItem(i).setChecked(false);
            }
            bottomNavigationView.getMenu().setGroupCheckable(0, true, true);
        }else if(item.getItemId() == R.id.nav_salir){
            //Introducimos una alerta para asegurar el cierre de la aplicacion
            new AlertDialog.Builder(Toolbar.this)
                    .setMessage("¿Estás seguro de que quieres salir?")
                    .setCancelable(false)
                    .setPositiveButton("Sí", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            finishAffinity();
                        }
                    })
                    .setNegativeButton("No", null)
                    .show();
            return true;
        }

        //Cambiar el fragmento
        if(selectedFragment != null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}